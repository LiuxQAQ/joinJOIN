window.addEventListener("load", function() {
    
    var sign_user = document.getElementById('jr_name');
    var rname_false = document.getElementById('rname-false');
    var rname_right = document.getElementById('rname-right');
    sign_user.onblur = function() {
        console.log("on");
        if(sign_user.value == ""){
            rname_right.style.display = 'none';
            rname_false.style.display = 'block';
        }else {
            rname_false.style.display = 'none';
            rname_right.style.display = 'block';
        }
    }
    var sign_sex = document.getElementById('jr_sex');
    var rsex_false = document.getElementById('rsex-false');
    var rsex_right = document.getElementById('rsex-right');
    sign_sex.onblur = function() {
        console.log("on");
        if(sign_sex.value == ""){
            rsex_right.style.display = 'none';
            rsex_false.style.display = 'block';
        }else {
            rsex_false.style.display = 'none';
            rsex_right.style.display = 'block';
        }
    }
    var sign_birthday = document.getElementById('jr_birthday');
    var rbirth_false = document.getElementById('rbirth-false');
    var rbirth_right = document.getElementById('rbirth-right');
    sign_birthday.onblur = function() {
        console.log("on");
        if(sign_birthday.value == ""){
            rbirth_right.style.display = 'none';
            rbirth_false.style.display = 'block';
        }else {
            rbirth_false.style.display = 'none';
            rbirth_right.style.display = 'block';
        }
    }
    var sign_grade = document.getElementById('jr_grade');
    var rgrade_false = document.getElementById('rgrade-false');
    var rgrade_right = document.getElementById('rgrade-right');
    sign_grade.onblur = function() {
        console.log("on");
        if(sign_grade.value == ""){
            rgrade_right.style.display = 'none';
            rgrade_false.style.display = 'block';
        }else {
            rgrade_false.style.display = 'none';
            rgrade_right.style.display = 'block';
        }
    }
    var sign_account = document.getElementById('jr_id');
    var raccount_false = document.getElementById('raccount-false');
    var raccount_right = document.getElementById('raccount-right');
    sign_account.onblur = function() {
        console.log("on");
        if(sign_account.value == ""){
            raccount_right.style.display = 'none';
            raccount_false.style.display = 'block';
        }else {
            raccount_false.style.display = 'none';
            raccount_right.style.display = 'block';
        }
    }
    var sign_profession = document.getElementById('jr_profession');
    var rpro_false = document.getElementById('rpro-false');
    var rpro_right = document.getElementById('rpro-right');
    sign_profession.onblur = function() {
        console.log("on");
        if(sign_profession.value == ""){
            rpro_right.style.display = 'none';
            rpro_false.style.display = 'block';
        }else {
            rpro_false.style.display = 'none';
            rpro_right.style.display = 'block';
        }
    }
    var sign_phone = document.getElementById('jr_phone');
    var rphone_false = document.getElementById('rphone-false');
    var rphone_right = document.getElementById('rphone-right');
    sign_phone.onblur = function() {
        console.log("on");
        regex = /^(?:\+?86)?1(?:3\d{3}|5[^4\D]\d{2}|8\d{3}|7(?:[235-8]\d{2}|4(?:0\d|1[0-2]|9\d))|9[0-35-9]\d{2}|66\d{2})\d{6}$/;
        if(!sign_phone.value.match(regex)){
            rphone_right.style.display = 'none';
            rphone_false.style.display = 'block';
        }else {
            rphone_false.style.display = 'none';
            rphone_right.style.display = 'block';
        }
    }
    var sign_email = document.getElementById('jr_email');
    var rema_false = document.getElementById('rema-false');
    var rema_right = document.getElementById('rema-right');
    sign_email.onchange = function() {
        console.log("on");
        regex = /^([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/;
        if(!sign_email.value.match(regex)){
            rema_right.style.display = 'none';
            rema_false.style.display = 'block';
        }else {
            rema_false.style.display = 'none';
            rema_right.style.display = 'block';
        }
    }
    var code = document.getElementById('code');
    var rcode_false = document.getElementById('rcode-false');
    var rcode_right = document.getElementById('rcode-right');
    code.onblur = function() {
        console.log("on");
        if(code.value == ""){
            rcode_right.style.display = 'none';
            rcode_false.style.display = 'block';
        }else {
            rcode_false.style.display = 'none';
            rcode_right.style.display = 'block';
        }
    }

    // 限制文本域文字字数
    
    var jrIntroduct = document.getElementById("jr_introduct");
    jrIntroduct.onkeyup = function() {
        console.log("textarea");
            var tValue = this.value;
            // console.log(tValue);
            console.log(tValue.length,"keyup");
            var maxLength = 250;
            var lessToWrite = maxLength - tValue.length;
            if(tValue.length > maxLength) {
                // alert("超过限制数字");
                // var showT = tValue.substring(0,200)
                // console.log(showT);
                this.value = tValue.substring(0,250);
            }else {
                var in1 = document.getElementById("in1");
                in1.style.width = 130 + 'px';
                in1.innerText = "还可以写"+lessToWrite+"个字";
            }
    }
    jrIntroduct.onkeydown = function() {
        console.log("textarea");
            var tValue = this.value;
            // console.log(tValue);
            console.log(tValue.length,"kepdown");
            var maxLength = 250;
            var lessToWrite = maxLength - tValue.length;
            if(tValue.length > maxLength) {
                // alert("超过限制数字");
                // var showT = tValue.substring(0,200)
                // console.log(showT);
                this.value = tValue.substring(0,250);
            }else {
                var in1 = document.getElementById("in1");
                in1.style.width = 130 + 'px';
                in1.innerText = "还可以写"+lessToWrite+"个字";
            }
    }

    jrIntroduct.onchange = function() {
        console.log("textarea");
            var tValue = this.value;
            // console.log(tValue);
            console.log(tValue.length,"change");
            var maxLength = 250;
            var lessToWrite = maxLength - tValue.length;
            if(tValue.length > maxLength) {
                // alert("超过限制数字");
                // var showT = tValue.substring(0,200)
                // console.log(showT);
                this.value = tValue.substring(0,250);
            }else {
                var in1 = document.getElementById("in1");
                in1.style.width = 130 + 'px';
                in1.innerText = "还可以写"+lessToWrite+"个字";
            }
    }
    var jrUnderst = document.getElementById("jr_underst");
    jrUnderst.onkeyup = function() {
        console.log("textarea");
            var tValue = this.value;
            console.log(tValue);
            console.log(tValue.length);
            var maxLength = 250;
            var lessToWrite = maxLength - tValue.length;
            if(tValue.length > maxLength) {
                // var showT = tValue.substring(0,maxLength)
                // console.log(showT.length);
                this.value = tValue.substring(0,250);
            }else {
                var in2 = document.getElementById("in2");
                in2.style.width = 130 + 'px';
                in2.innerText = "还可以写"+lessToWrite+"个字";
            }
    }
    jrUnderst.onkeydown = function() {
        console.log("textarea");
            var tValue = this.value;
            console.log(tValue);
            console.log(tValue.length);
            var maxLength = 250;
            var lessToWrite = maxLength - tValue.length;
            if(tValue.length > maxLength) {
                // var showT = tValue.substring(0,maxLength)
                // console.log(showT.length);
                this.value = tValue.substring(0,250);
            }else {
                var in2 = document.getElementById("in2");
                in2.style.width = 130 + 'px';
                in2.innerText = "还可以写"+lessToWrite+"个字";
            }
    }
    jrUnderst.onchange = function() {
        console.log("textarea");
            var tValue = this.value;
            console.log(tValue);
            console.log(tValue.length);
            var maxLength = 250;
            var lessToWrite = maxLength - tValue.length;
            if(tValue.length > maxLength) {
                // var showT = tValue.substring(0,maxLength)
                // console.log(showT.length);
                this.value = tValue.substring(0,250);
            }else {
                var in2 = document.getElementById("in2");
                in2.style.width = 130 + 'px';
                in2.innerText = "还可以写"+lessToWrite+"个字";
            }
    }
    var jrExperien = document.getElementById("jr_experien");
    jrExperien.onkeyup = function() {
        console.log("textarea");
            var tValue = this.value;
            console.log(tValue);
            console.log(tValue.length);
            var maxLength = 250;
            var lessToWrite = maxLength - tValue.length;
            if(tValue.length > maxLength) {
                // var showT = tValue.substring(0,maxLength)
                // console.log(showT.length);
                this.value = tValue.substring(0,250);
            }else {
                var in3 = document.getElementById("in3");
                in3.style.width = 130 + 'px';
                in3.innerText = "还可以写"+lessToWrite+"个字";
            }
    }
    jrExperien.onkeydown = function() {
        console.log("textarea");
            var tValue = this.value;
            console.log(tValue);
            console.log(tValue.length);
            var maxLength = 250;
            var lessToWrite = maxLength - tValue.length;
            if(tValue.length > maxLength) {
                // var showT = tValue.substring(0,maxLength)
                // console.log(showT.length);
                this.value = tValue.substring(0,250);
            }else {
                var in3 = document.getElementById("in3");
                in3.style.width = 130 + 'px';
                in3.innerText = "还可以写"+lessToWrite+"个字";
            }
    }
    jrExperien.onchange = function() {
        console.log("textarea");
            var tValue = this.value;
            console.log(tValue);
            console.log(tValue.length);
            var maxLength = 250;
            var lessToWrite = maxLength - tValue.length;
            if(tValue.length > maxLength) {
                // var showT = tValue.substring(0,maxLength)
                // console.log(showT.length);
                this.value = tValue.substring(0,250);
            }else {
                var in3 = document.getElementById("in3");
                in3.style.width = 130 + 'px';
                in3.innerText = "还可以写"+lessToWrite+"个字";
            }
    }

    // 发送邮箱验证码
    // var t;
    // var getcode = document.getElementById('getcode');
    // var sign_email = document.getElementById('jr_email').value;
    // getcode.onclick = function(e) {
    //     var sign_email = document.getElementById('jr_email').value;
    //     console.log(sign_email);
    //     var regex = /^([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/;
    //     if(!sign_email.match(regex)){
    //         var el = document.createElement("div");
    //         el.setAttribute("class", "warningAll");
    //         el.innerText = "邮箱有误，请重填！";
    //         document.body.appendChild(el);
    //         el.classList.add("bounce-enter-active");
    //         setTimeout(() => {
    //             console.log("setTime");
    //             el.classList.remove("bounce-enter-active");
    //             el.classList.add("bounce-leave-active");
    //         }, 3000);
    //     }else {
    //         var signEmail = document.getElementById('jr_email').value;
    //         var root = {
    //             userEmail: signEmail
    //         }
    //         console.log(root);
    //         var str = JSON.stringify(root);
    //         console.log(str);
    //         let xhr = new XMLHttpRequest();
    //         xhr.open('post', '/joinplat/junior/tourist', true);
    //         xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
    //         xhr.withCredentials = true;
    //         xhr.send(str);
    //         xhr.onreadystatechange = function() {
    //             if (xhr.status === 200) {
    //                 var res = JSON.parse(xhr.responseText);
    //                 console.log(res);
    //                 if (res.code == 200) {
    //                     var el = document.createElement("div");
    //                     el.setAttribute("class", "warningSuccess");
    //                     el.innerText = "发送成功，请查看邮箱！";
    //                     document.body.appendChild(el);
    //                     el.classList.add("bounce-enter-active");
    //                     setTimeout(() => {
    //                         console.log("setTime");
    //                         el.classList.remove("bounce-enter-active");
    //                     el.classList.add("bounce-leave-active");
    //                     }, 3000);
    //                 } else {
    //                     var el = document.createElement("div");
    //                     el.setAttribute("class", "warningAll");
    //                     el.innerText = res.message;
    //                     document.body.appendChild(el);
    //                     el.classList.add("bounce-enter-active");
    //                     setTimeout(() => {
    //                         console.log("setTime");
    //                         el.classList.remove("bounce-enter-active");
    //                         el.classList.add("bounce-leave-active");
    //                     }, 3000);
    //                 }
    //             }
    //         }
    //         t = setInterval(function () {
    //             countdown(e)
    //         },1000)
    //         countdown(e);
    //     }
    // }
    // var time = 60 ; 
    // function countdown(e) {
    //     if(time == 0){
    //         e.setAttribute("onclick","getcode(this)");
    //         document.getElementById("getcode").innerText = "获取验证码";
    //         time = 60;
    //         clearInterval(t);
    //     }else {
    //         e.setAttribute("onclick",'');
    //         document.getElementById("getcode").innerText = "重新发送"+time;
    //         time--;
    //     }
    // }
    

    // 文件上传
    var File = document.getElementById("file");
    var box = document.getElementById("box");
    box.onclick = function(e) {
        if(File) {
            File.click();
        }
        e.preventDefault();
    }
    var abbeImg = document.getElementById("abbeImg");
    let reader = new FileReader;
    File.onchange = function() {
            console.log(File);
            console.log("box file");
            console.log(this.files[0]);
            console.log(this.files[0].size);
            var file = this.files[0];
            if (!/(png|jpg|gif|jpeg)/i.test(file.type)) {
                alert('请上传PNG/JPG/GIF格式的图片');
                return;
            }
            // FileReader 文件读取类 （异步读取）
            // let reader = new FileReader;
            reader.readAsDataURL(file);
            reader.onload = function(ev) {
                //ev.target.result 读取出来的BASE64
                abbeImg.src = ev.target.result;
            }
        }
      
        var f_volunte = document.getElementsByName("jr_f_volunte");
        var s_volunte = document.getElementsByName("jr_s_volunte");
        var jrfVol = document.getElementById("jrfVol");
        var jrsVol = document.getElementById("jrsVol");
       jrfVol.onclick = function() {
           for(var i = 0 ; i < f_volunte.length ; i ++) {
               if(f_volunte[i].checked == true) {
                   console.log(i);
                   s_volunte[i].checked = false;
               }
           }
       }
       jrsVol.onclick = function() {
        for(var i = 0 ; i < s_volunte.length ; i ++) {
            if(s_volunte[i].checked == true) {
                console.log(i);
                f_volunte[i].checked = false;
            }
        }
    }


        // 提交表单
    var firstSubmit = document.getElementById("firstSubmit");
    firstSubmit.onclick = function() {
            var jr_id = document.getElementById("jr_id").value;
            var jr_name = document.getElementById("jr_name").value;
            var jr_sex = document.getElementById("jr_sex").value;
            var jr_grade = document.getElementById("jr_grade").value;
            var jr_profession = document.getElementById("jr_profession").value;
            var jr_phone = document.getElementById("jr_phone").value;
            var jr_birthday = document.getElementById("jr_birthday").value;
            var jr_email = document.getElementById("jr_email").value;
            var jr_code = document.getElementById("code").value;
            var f_volunte = document.getElementsByName("jr_f_volunte");
            var s_volunte = document.getElementsByName("jr_s_volunte");
            var jr_adjust = 1;
            var jr_f_volunte = "";
            var jr_s_volunte = "";
            for (var i = 0; i < f_volunte.length; i++) {
                if (f_volunte[i].checked == true) {
                    jr_f_volunte = f_volunte[i].value;
                    console.log(jr_f_volunte);
                }
            }
            for (var i = 0; i < s_volunte.length; i++) {
                if (s_volunte[i].checked == true) {
                    jr_s_volunte = s_volunte[i].value;
                    console.log(jr_s_volunte);
                }
            }
            for (var i = 0; i < jr_adjust.length; i++) {
                if (jr_adjust[i].checked == true) {
                    var jrAdjust = jr_adjust[i].value;
                    console.log(jrAdjust);
                }
            }
            var jr_underst = document.getElementById("jr_underst").value;
            var jr_experien = document.getElementById("jr_experien").value;
            var jr_introduct = document.getElementById("jr_introduct").value;
            console.log("submit");
            var data = {
                jr_id :jr_id,
                jr_birthday : jr_birthday,
                jr_name : jr_name,
                jr_code : jr_code,
                jr_sex : jr_sex,
                jr_email : jr_email,
                jr_phone : jr_phone,
                jr_experien : jr_experien,
                jr_underst : jr_underst,
                jr_f_volunte : jr_f_volunte,
                jr_s_volunte : jr_s_volunte,
                jr_introduct : jr_introduct
            }
            console.log(data);
            if(jr_id == "" || jr_name == "" || jr_phone == ""|| jr_birthday == "" || jr_sex == "" || jr_profession == "" || jr_grade == ""|| jr_f_volunte == ""|| jr_s_volunte == "" || jr_email == "" || jr_experien == "" || jr_introduct == "" || jr_underst == "" || jr_code == ""){
                var el = document.createElement("div");
                el.setAttribute("class", "warningAll");
                el.innerText = "请完整填写报名表内容！";
                document.body.appendChild(el);
                el.classList.add("bounce-enter-active");
                // warningAll.style.display = 'block';
                setTimeout(() => {
                    console.log("setTime");
                    el.classList.remove("bounce-enter-active");
                    el.classList.add("bounce-leave-active");
                    // warningAll.style.display = 'none';
                }, 2000);
                // alert("提交失败，请检查！");
                console.log("失败了");
            }else {
                var formData = new FormData();
                formData.append('jrId', jr_id);
                formData.append('jrName', jr_name);
                formData.append('jrPhone', jr_phone);
                formData.append('jrBirthday', jr_birthday);
                formData.append('jrSex', jr_sex);
                formData.append('jrProfession', jr_profession);
                formData.append('jrGrade', jr_grade);
                formData.append('jrFVolunte', jr_f_volunte);
                formData.append('jrSVolunte', jr_s_volunte);
                formData.append('jrAdjust', jr_adjust);
                formData.append('jrEmail', jr_email);
                formData.append('code', jr_code);
                formData.append('jrIntroduct', jr_introduct);
                formData.append('jrExperien', jr_experien);
                formData.append('jrUnderst', jr_underst);
                formData.append('file', File.files[0]);
                console.log(formData);

                let xhr = new XMLHttpRequest();
                xhr.open('post', '/joinplat/junior/form/upload', true);
                xhr.withCredentials = true;
                xhr.send(formData);
                xhr.onreadystatechange = function() {
                    if (xhr.status === 200) {
                        var res = JSON.parse(xhr.responseText);
                        if (res.code == 200) {
                            var el = document.createElement("div");
                            el.setAttribute("class", "warningSuccess");
                            el.innerText = "成功提交报名表~~~等待我们的面试通知吧！";
                            document.body.appendChild(el);
                            el.classList.add("bounce-enter-active");
                            setTimeout(() => {
                                console.log("setTime");
                                el.classList.remove("bounce-enter-active");
                                el.classList.add("bounce-leave-active");
                            }, 3000);
                            setTimeout(() => {
                                window.location.href = '../shouye/index.html';
                            },2000);
                            console.log("成功");
                        } else {
                            var el = document.createElement("div");
                            el.setAttribute("class", "warningAll");
                            el.innerText = res.message;
                            document.body.appendChild(el);
                            el.classList.add("bounce-enter-active");
                            // warningAll.style.display = 'block';
                            setTimeout(() => {
                                console.log("setTime");
                                el.classList.remove("bounce-enter-active");
                                el.classList.add("bounce-leave-active");
                                // warningAll.style.display = 'none';
                            }, 3000);
                            // alert("提交失败，请检查！");
                            console.log("失败了");
                        }
                    }
                }

            }
        }
        // 再次提交报名表
    
})