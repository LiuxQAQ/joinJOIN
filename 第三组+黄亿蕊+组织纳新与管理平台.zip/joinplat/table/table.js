window.addEventListener("load", function() {
    
    var inputs = document.getElementsByTagName("input");
    console.log(inputs.length);
    var texts = document.getElementsByClassName(".text");
    var inputs_length = inputs.length;
    console.log(texts.length);
    for (var i = 0; i < inputs_length; i++) {
        inputs[i].onblur = function() {
                console.log("onblur");
                // console.log(inputs[i].value);
                // if(inputs[i].value != ""){
                // console.log("值不为空");
                // texts[i].style.top = '0.1%';
                // texts[i].style.fontSize = '10%';
                // }else {
                // console.log("值为空");
                // texts[i].style.top = '30%';
                // texts[i].style.fontSize = '90%';
                // }
                // texts[i].classList += 'current';
            }
            // inputs[i].addEventListener("mouseup",function(){
            //     console.log("keyup");
            //     if(inputs[i].value != ""){
            //         texts[i].classList += 'current';
            //     }

        // })
    }

    // 发送邮箱验证码
    var getcode = document.getElementById('getcode');
    console.log(getcode);
    getcode.onclick = function() {
        console.log("click button");
        var signEmail = document.getElementById('jr_email').value;
        var root = {
            userEmail: signEmail
        }
        console.log(root);
        var str = JSON.stringify(root);
        console.log(str);
        let xhr = new XMLHttpRequest();
        // xhr.responseType = 'json';
        xhr.open('post', '/joinplat/junior/tourist', true);
        xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
        xhr.withCredentials = true;
        xhr.send(str);
        xhr.onreadystatechange = function() {
            if (xhr.status === 200) {
                var res = JSON.parse(xhr.responseText);
                console.log(res);
                if (res.code == 200) {
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningSuccess");
                    el.innerText = res.message;
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 2000);
                } else {
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningAll");
                    el.innerText = res.message;
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 2000);
                } 
            }
        }
    }

    // 文件上传
    var File = document.getElementById("file");
    var box = document.getElementById("box");
    var abbeImg = document.getElementById("abbeImg");
    let reader = new FileReader;
    File.onchange = function() {
            console.log(File);
            console.log("box file");
            console.log(this.files[0]);
            console.log(this.files[0].size);
            var file = this.files[0];
            if (!/(png|jpg|gif|jpeg)/i.test(file.type)) {
                alert('请上传PNG/JPG/GIF格式的图片');
                return;
            }
            // FileReader 文件读取类 （异步读取）
            // let reader = new FileReader;
            reader.readAsDataURL(file);
            reader.onload = function(ev) {
                //ev.target.result 读取出来的BASE64
                abbeImg.src = ev.target.result;
            }
        }
        // var headerImg = document.getElementById('abbeImg').src;
        // console.log(headerImg);
        // console.log(File.files[0]);
        // 提交表单
    var firstSubmit = document.getElementById("firstSubmit");
    firstSubmit.onclick = function() {
            console.log("submit");
            var jr_id = document.getElementById("jr_id").value;
            var jr_name = document.getElementById("jr_name").value;
            var jr_sex = document.getElementById("jr_sex").value;
            var jr_grade = document.getElementById("jr_grade").value;
            var jr_profession = document.getElementById("jr_profession").value;
            var jr_phone = document.getElementById("jr_phone").value;
            var jr_birthday = document.getElementById("jr_birthday").value;
            var jr_email = document.getElementById("jr_email").value;
            var jr_code = document.getElementById("code").value;
            var f_volunte = document.getElementsByName("jr_f_volunte");
            var s_volunte = document.getElementsByName("jr_s_volunte");
            var jr_adjust = 1;
            for (var i = 0; i < f_volunte.length; i++) {
                if (f_volunte[i].checked == true) {
                    var jr_f_volunte = f_volunte[i].value;
                    console.log(jr_f_volunte);
                }
            }
            for (var i = 0; i < s_volunte.length; i++) {
                if (s_volunte[i].checked == true) {
                    var jr_s_volunte = s_volunte[i].value;
                    console.log(jr_s_volunte);
                }
            }
            for (var i = 0; i < jr_adjust.length; i++) {
                if (jr_adjust[i].checked == true) {
                    var jrAdjust = jr_adjust[i].value;
                    console.log(jrAdjust);
                }
            }
            var jr_underst = document.getElementById("jr_underst").value;
            var jr_experien = document.getElementById("jr_experien").value;
            var jr_introduct = document.getElementById("jr_introduct").value;
            var data = {
                jr_id :jr_id,
                jr_birthday : jr_birthday,
                jr_name : jr_name,
                jr_code : jr_code,
                jr_sex : jr_sex,
                jr_email : jr_email,
                jr_phone : jr_phone,
                jr_experien : jr_experien,
                jr_underst : jr_underst,
                jr_f_volunte : jr_f_volunte,
                jr_s_volunte : jr_s_volunte,
                jr_introduct : jr_introduct
            }
            console.log(data);
            var formData = new FormData();
            formData.append('jrId', jr_id);
            formData.append('jrName', jr_name);
            formData.append('jrPhone', jr_phone);
            formData.append('jrBirthday', jr_birthday);
            formData.append('jrSex', jr_sex);
            formData.append('jrProfession', jr_profession);
            formData.append('jrGrade', jr_grade);
            formData.append('jrFVolunte', jr_f_volunte);
            formData.append('jrSVolunte', jr_s_volunte);
            formData.append('jrAdjust', jrAdjust);
            formData.append('jrEmail', jr_email);
            formData.append('code', jr_code);
            formData.append('jrIntroduct', jr_introduct);
            formData.append('jrExperien', jr_experien);
            formData.append('jrUnderst', jr_underst);
            formData.append('file', File.files[0]);
            console.log(formData);
            let xhr = new XMLHttpRequest();
            xhr.open('post','/joinplat/junior/form/upload', true);
            xhr.withCredentials = true;
            xhr.send(formData);
            xhr.onreadystatechange = function() {
                if (xhr.status === 200) {
                    var res = JSON.parse(xhr.responseText);
                    if (res.code == 200) {
                        var el = document.createElement("div");
                        el.setAttribute("class", "warningSuccess");
                        el.innerText = "您已成功提交JOIN报名表~~~等待我们的面试通知吧！";
                        document.body.appendChild(el);
                        el.classList.add("bounce-enter-active");
                        // warningAll.style.display = 'block';
                        setTimeout(() => {
                            console.log("setTime");
                            el.classList.remove("bounce-enter-active");
                            el.classList.add("bounce-leave-active");
                            // warningAll.style.display = 'none';
                        }, 2000);
                        // alert("报名表提交成功了！");
                        console.log("成功");
                    } else {
                        var el = document.createElement("div");
                        el.setAttribute("class", "warningAll");
                        el.innerText = res.message;
                        document.body.appendChild(el);
                        el.classList.add("bounce-enter-active");
                        // warningAll.style.display = 'block';
                        setTimeout(() => {
                            console.log("setTime");
                            el.classList.remove("bounce-enter-active");
                            el.classList.add("bounce-leave-active");
                            // warningAll.style.display = 'none';
                        }, 2000);
                        // alert("提交失败，请检查！");
                        console.log("失败了");
                    }
                }
            }
        }
        // 再次提交报名表
    var secondSubmit = document.getElementById("secondSubmit");
    secondSubmit.onclick = function() {
        console.log("submit");
        var jr_id = document.getElementById("jr_id").value;
        var jr_name = document.getElementById("jr_name").value;
        var jr_sex = document.getElementById("jr_sex").value;
        var jr_grade = document.getElementById("jr_grade").value;
        var jr_profession = document.getElementById("jr_profession").value;
        var jr_phone = document.getElementById("jr_phone").value;
        var jr_birthday = document.getElementById("jr_birthday").value;
        var jr_email = document.getElementById("jr_email").value;
        var jr_code = document.getElementById("code").value;
        var f_volunte = document.getElementsByName("jr_f_volunte");
        var s_volunte = document.getElementsByName("jr_s_volunte");
        var jr_adjust = document.getElementsByName("readjust");
        for (var i = 0; i < f_volunte.length; i++) {
            if (f_volunte[i].checked == true) {
                var jr_f_volunte = f_volunte[i].value;
                console.log(jr_f_volunte);
            }
        }
        for (var i = 0; i < s_volunte.length; i++) {
            if (s_volunte[i].checked == true) {
                var jr_s_volunte = s_volunte[i].value;
                console.log(jr_s_volunte);
            }
        }
        for (var i = 0; i < jr_adjust.length; i++) {
            if (jr_adjust[i].checked == true) {
                var jrAdjust = jr_adjust[i].value;
                console.log(jrAdjust);
            }
        }
        var jr_underst = document.getElementById("jr_underst").value;
        var jr_experien = document.getElementById("jr_experien").value;
        var jr_introduct = document.getElementById("jr_introduct").value;
        var formData = new FormData();
        formData.append('jrId', jr_id);
        formData.append('jrName', jr_name);
        formData.append('jrPhone', jr_phone);
        formData.append('jrBirthday', jr_birthday);
        formData.append('jrSex', jr_sex);
        formData.append('jrProfession', jr_profession);
        formData.append('jrGrade', jr_grade);
        formData.append('jrFVolunte', jr_f_volunte);
        formData.append('jrSVolunte', jr_f_volunte);
        formData.append('jrAdjust', jrAdjust);
        formData.append('jrEmail', jr_email);
        formData.append('code', jr_code);
        formData.append('jrIntroduct', jr_introduct);
        formData.append('jrExperien', jr_experien);
        formData.append('jrUnderst', jr_underst);
        // formData.append('data',data);
        formData.append('file', File.files[0]);
        console.log(formData);
        let xhr = new XMLHttpRequest();
        xhr.open('post', '/joinplat/junior/form/upload', true);
        xhr.withCredentials = true
        xhr.send(formData);
        xhr.onreadystatechange = function() {
            if (xhr.status === 200) {
                var res = JSON.parse(xhr.responseText);
                if (res.code == 200) {
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningSuccess");
                    el.innerText = "您已成功提交JION报名表~~~等待我们的面试通知吧！";
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 2000);
                    // alert("报名表提交成功了！");
                    console.log("成功");
                    // alert("报名表提交成功了！");
                    // console.log("成功");
                } else {
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningAll");
                    el.innerText = res.message;
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 2000);
                    // alert("提交失败，请检查！");
                    console.log("失败了");
                    // alert("提交失败，请检查！");
                    // console.log("失败了");
                }
            }
        }
    }
})