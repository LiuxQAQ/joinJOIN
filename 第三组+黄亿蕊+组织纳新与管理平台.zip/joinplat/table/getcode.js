 // 发送邮箱验证码
 var t;
//  var getcode = document.getElementById('getcode');
 // var sign_email = document.getElementById('jr_email').value;
 function getcode(e) {
     var sign_email = document.getElementById('jr_email').value;
     console.log(sign_email);
     var regex = /^([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/;
     if(!sign_email.match(regex)){
         var el = document.createElement("div");
         el.setAttribute("class", "warningAll");
         el.innerText = "邮箱有误，请重填！";
         document.body.appendChild(el);
         el.classList.add("bounce-enter-active");
         // warningAll.style.display = 'block';
         setTimeout(() => {
             console.log("setTime");
             el.classList.remove("bounce-enter-active");
             el.classList.add("bounce-leave-active");
             // warningAll.style.display = 'none';
         }, 3000);
     }else {
         var signEmail = document.getElementById('jr_email').value;
         var root = {
             userEmail: signEmail
         }
         console.log(root);
         var str = JSON.stringify(root);
         console.log(str);
         let xhr = new XMLHttpRequest();
         xhr.open('post', '/joinplat/junior/tourist', true);
         xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
         xhr.withCredentials = true;
         xhr.send(str);
         xhr.onreadystatechange = function() {
             if (xhr.status === 200) {
                 var res = JSON.parse(xhr.responseText);
                 console.log(res);
                 if (res.code == 200) {
                     var el = document.createElement("div");
                     el.setAttribute("class", "warningSuccess");
                     el.innerText = "发送成功，请查看邮箱！";
                     document.body.appendChild(el);
                     el.classList.add("bounce-enter-active");
                     // warningAll.style.display = 'block';
                     setTimeout(() => {
                         console.log("setTime");
                         el.classList.remove("bounce-enter-active");
                     el.classList.add("bounce-leave-active");
                         // warningAll.style.display = 'none';
                     }, 3000);
                 } else {
                     var el = document.createElement("div");
                     el.setAttribute("class", "warningAll");
                     el.innerText = res.message;
                     document.body.appendChild(el);
                     el.classList.add("bounce-enter-active");
                     // warningAll.style.display = 'block';
                     setTimeout(() => {
                         console.log("setTime");
                         el.classList.remove("bounce-enter-active");
                         el.classList.add("bounce-leave-active");
                     // warningAll.style.display = 'none';
                     }, 3000);
                 }
             }
         }
         t = setInterval(function () {
             countdown(e)
         },1000)
         countdown(e);
     }
 }
 var time = 60 ; 
 function countdown(e) {
     if(time == 0){
         e.setAttribute("onclick","getcode(this)");
         document.getElementById("getcode").innerText = "获取验证码";
         time = 60;
         clearInterval(t);
     }else {
         e.setAttribute("onclick",'');
         document.getElementById("getcode").innerText = "重新发送"+time;
         time--;
     }
 }