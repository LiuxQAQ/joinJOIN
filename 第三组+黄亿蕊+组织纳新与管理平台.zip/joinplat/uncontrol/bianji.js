var bianji = document.getElementById('bianji');
var ID = location.search.split('=')[1];
console.log(ID);

bianji.onclick = {
    // window.location.href = "../公告编辑/new.html?id=ID";
}