window.addEventListener("load", function() {
    // 判断学号是否填写
    var usercnt = document.getElementById("sign-account");
    usercnt.onblur = function() {
            console.log("account change");
            var warnings = document.getElementById("signAccount").children[2];
            if (usercnt.value == "") {
                warnings.style.display = 'block';
            } else {
                warnings.style.display = 'none';
            }
        }
        // 判断邮箱是否符合规范
    var userel = document.getElementById("sign-email");
    userel.onchange = function() {
            regex = /^([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/;
            var warnings = document.getElementById("signEmail").children[2];
            if (!userel.value.match(regex)) {
                warnings.style.display = 'block';
            } else {
                warnings.style.display = 'none';
            }
        }
        // 判断密码是否为空
    var userpwd = document.getElementById("sign-password");
    userpwd.onblur = function() {
            console.log("pwd change");
            var warnings = document.getElementById("signPwd").children[2];
            if (userpwd.value == "") {
                warnings.style.display = 'block';
            } else {
                warnings.style.display = 'none';
            }

        }
        // 确认密码
    var userpwdAc = document.getElementById("sign-password-accept");
    userpwdAc.onblur = function() {
        console.log("pwd again");
        var warnings = document.getElementById("signPwdAccept").children[2];
        var userpwd = document.getElementById("sign-password");
        console.log(userpwdAc.value, userpwd.value);
        if (userpwdAc.value != userpwd.value) {
            warnings.style.display = 'block';
        } else {
            warnings.style.display = 'none';
        }
    }

    // 发送邮箱验证码
    var getcode = document.getElementById('getcode');
    console.log(getcode);
    getcode.onclick = function() {
        console.log("click button");
        var signEmail = document.getElementById('sign-email').value;
        var root = {
            userEmail: signEmail
        }
        console.log(root);
        var str = JSON.stringify(root);
        console.log(str);
        let xhr = new XMLHttpRequest();
        // xhr.responseType = 'json';
        xhr.open('post', link + '/joinplat/community/forgetPwd', true);
        xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
        xhr.withCredentials = true;
        xhr.send(str);
        xhr.onreadystatechange = function() {
            if (xhr.status === 200) {
                var res = JSON.parse(xhr.responseText);
                console.log(res);
                if (res.code == 200) {
                    // alert("发送成功");
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningSuccess");
                    el.innerText = "发送成功，请查看邮箱！";
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 2000);
                } else {
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningAll");
                    el.innerText = res.message;
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 2000);

                }
            }
        }
    }



    //  提交修改密码
    var rewrite = document.getElementById('submit');
    rewrite.onclick = function() {
        console.log("rewrite");
        var userPwd = true;
        var userpwd = document.getElementById("sign-password");
        var userpwdAc = document.getElementById("sign-password-accept");
        if (userpwd.value == "" || userpwdAc.value == "" || userpwdAc.value != userpwd.value) {
            userPwd = false;
        } else {
            userPwd = true;
        }
        console.log(userpwd, userpwdAc);
        var sign_password = document.getElementById("sign-password").value;
        var sign_email = document.getElementById("sign-email").value;
        var sign_code = document.getElementById('code').value;
        var sign_account = document.getElementById("sign-account").value;
        if (sign_account == "" || sign_code == "" || sign_email == "" || sign_password != userpwdAc.value) {
            let root = {
                userPassword: sign_password,
                userEmail: sign_email,
                // userPhone : sign_phone,
                // userGender : sign_sex,
                // 邮箱验证码
                code: sign_code,
                userAccount: sign_account
            }
            console.log(root);
            var str = JSON.stringify(root);
            console.log(str);
            let xhr = new XMLHttpRequest();
            // xhr.responseType = 'json';
            //http://localhost:8080/community/registered
            xhr.open('post', link + '/community/resetPwd', true);
            xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
            xhr.withCredentials = true;
            xhr.send(str);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status == 200) {
                    var res = JSON.parse(xhr.responseText);
                    console.log(res);
                    if (res.code == 200) {
                        // alert("修改成功");
                        var el = document.createElement("div");
                        el.setAttribute("class", "warningSuccess");
                        el.innerText = "修改成功！";
                        document.body.appendChild(el);
                        el.classList.add("bounce-enter-active");
                        // warningAll.style.display = 'block';
                        setTimeout(() => {
                            console.log("setTime");
                            el.classList.remove("bounce-enter-active");
                            el.classList.add("bounce-leave-active");
                            // warningAll.style.display = 'none';
                        }, 2000);
                        window.location = '../log_reg/newlog.html';
                    } else {
                        // alert(res.message);
                        var el = document.createElement("div");
                        el.setAttribute("class", "warningAll");
                        el.innerText = res.message;
                        document.body.appendChild(el);
                        el.classList.add("bounce-enter-active");
                        // warningAll.style.display = 'block';
                        setTimeout(() => {
                            console.log("setTime");
                            el.classList.remove("bounce-enter-active");
                            el.classList.add("bounce-leave-active");
                            // warningAll.style.display = 'none';
                        }, 3000);
                    }
                } else {
                    // alert("修改失败");
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningAll");
                    el.innerText = res.message;
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 3000);
                }
            }
        } else {
            var el = document.createElement("div");
            el.setAttribute("class", "warningAll");
            el.innerText = "请完整填写信息！";
            document.body.appendChild(el);
            el.classList.add("bounce-enter-active");
            // warningAll.style.display = 'block';
            setTimeout(() => {
                console.log("setTime");
                el.classList.remove("bounce-enter-active");
                el.classList.add("bounce-leave-active");
                // warningAll.style.display = 'none';
            }, 3000);
        }

    }
})