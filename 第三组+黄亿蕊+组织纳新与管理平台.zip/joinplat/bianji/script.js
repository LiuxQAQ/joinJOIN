window.addEventListener('load',function(){
    // 限制标题输入字数
    var annTitle = document.getElementById("annTitle");
    annTitle.onkeyup = function() {
        console.log("title");
            var tValue = this.value;
            // console.log(tValue);
            console.log(tValue.length,"keyup");
            var maxLength = 15;
            var lessToWrite = maxLength - tValue.length;
            if(tValue.length > maxLength) {
                // alert("超过限制数字");
                // var showT = tValue.substring(0,200)
                // console.log(showT);
                this.value = tValue.substring(0,15);
            }else {
                var in1 = document.getElementById("in1");
                in1.style.width = 130 + 'px';
                in1.innerText = "还可以写"+lessToWrite+"个字符";
            }
    }
    annTitle.onkeydown = function() {
        console.log("title");
            var tValue = this.value;
            // console.log(tValue);
            console.log(tValue.length,"kepdown");
            var maxLength = 15;
            var lessToWrite = maxLength - tValue.length;
            if(tValue.length > maxLength) {
                // alert("超过限制数字");
                // var showT = tValue.substring(0,200)
                // console.log(showT);
                this.value = tValue.substring(0,15);
            }else {
                var in1 = document.getElementById("in1");
                in1.style.width = 130 + 'px';
                in1.innerText = "还可以写"+lessToWrite+"个字符";
            }
    }
    annTitle.onchange = function() {
        console.log("title");
            var tValue = this.value;
            // console.log(tValue);
            console.log(tValue.length,"kepdown");
            var maxLength = 15;
            var lessToWrite = maxLength - tValue.length;
            if(tValue.length > maxLength) {
                // alert("超过限制数字");
                // var showT = tValue.substring(0,200)
                // console.log(showT);
                this.value = tValue.substring(0,15);
            }else {
                var in1 = document.getElementById("in1");
                in1.style.width = 130 + 'px';
                in1.innerText = "还可以写"+lessToWrite+"个字符";
            }
    }
     // 上传公告
     var submit = document.getElementById('submit');
     submit.onclick = function(){
         // let num_id = window.location.search.split("=")[1];
         var title = document.getElementById('annTitle').value;
         var div1 = document.getElementById('div1');
         console.log(div1);
         var content = document.getElementById('LAY_demo1').value;
         console.log(content);
         if(title == "" || content == "") {
            var el = document.createElement("div");
            el.setAttribute("class", "warningAll");
            el.innerText = "请将公告内容填写完整！";
            document.body.appendChild(el);
            el.classList.add("bounce-enter-active");
            // warningAll.style.display = 'block';
            setTimeout(() => {
                console.log("setTime");
                el.classList.remove("bounce-enter-active");
                el.classList.add("bounce-leave-active");
                // warningAll.style.display = 'none';
            }, 3000);
         }else {
            var root = {
                userAccount : 2022123,
                // userAccount : num_id,
                annTitle : title,
                announcement : content
            }
            console.log(root);
            var str = JSON.stringify(root);
            console.log(str);
            let xhr = new XMLHttpRequest();
            xhr.open('post',link+'/joinplat/boss/from/update',true);
            xhr.setRequestHeader('Content-Type','application/json;charset=UTF-8');
            xhr.withCredentials = true;
            xhr.send(str);
            xhr.onreadystatechange = function(){
                if(xhr.status === 200){
                    var res = JSON.parse(xhr.responseText);
                    console.log(res);
                    if(res.code == 200){
                        // alert("发布成功");
                        var el = document.createElement("div");
                        el.setAttribute("class", "warningSuccess");
                        el.innerText = "发布成功！";
                        document.body.appendChild(el);
                        el.classList.add("bounce-enter-active");
                        // warningAll.style.display = 'block';
                        setTimeout(() => {
                            console.log("setTime");
                            el.classList.remove("bounce-enter-active");
                            el.classList.add("bounce-leave-active");
                            // warningAll.style.display = 'none';
                        }, 3000);
                        
                    }else {
                        // alert("发布失败");
                        var el = document.createElement("div");
                        el.setAttribute("class", "warningAll");
                        el.innerText = res.message;
                        document.body.appendChild(el);
                        el.classList.add("bounce-enter-active");
                        // warningAll.style.display = 'block';
                        setTimeout(() => {
                            console.log("setTime");
                            el.classList.remove("bounce-enter-active");
                            el.classList.add("bounce-leave-active");
                            // warningAll.style.display = 'none';
                        }, 3000);
                    }
                }
            }
        }
        
     }
    // 展示已有公告
    var xhr = new XMLHttpRequest();
    xhr.open('post',link+'/joinplat/boss/getAnnouncement',true);
    xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
    xhr.withCredentials = true;
    xhr.send();
    xhr.onreadystatechange = function() {
        if(xhr.status === 200){
            var res = JSON.parse(xhr.responseText);
            console.log(res);
            if(res.code == 200){
                var List = res.data.announcements;
                var showTab = document.getElementById("showTab");
                var show = "";
                show+=`
                    <tr class="firstone">
                        <th class="num">序号：</th>
                        <th class="title">标题：</th>
                        <th class="time">时间：</th>
                        <th class="textName">内容：</th>
                        <th class="dele">删除</th>
                    </tr>
                `;
                for(var i = 0; i < List.length ; i ++){
                    show +=`
                    <tr>
                        <td class="num">${i+1}</td>
                        <td class="title">${List[i].annTitle}</td>
                        <td class="time">${List[i].annTime}</td>
                        <td class="textName">${List[i].announcement}</td>
                        <td class="dele" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal"><span class="item_delete" data-id="${List[i].annTitle}" data-text="${List[i].announcement}">删除</span></td>
                    </tr>
                    `;
                }
                showTab.innerHTML = show;
         
                //  删除公告
                var newdata = {
                    annTitle : "纳新",
                    announcement : "jishubu"
                }
                var delete1 = document.querySelectorAll(".item_delete");
                for(var i = 0; i < delete1.length; i ++){
                    delete1[i].onclick = function(){
                        var proID = this.getAttribute("data-id");
                        var main_text = this.getAttribute("data-text");
                        newdata = {
                            annTitle : proID,
                            announcement : main_text
                        }
                    }
                }
                console.log(newdata);
                var del = document.getElementById("facetoface");
                // for(var i = 0 ;i < del.length; i ++){
                    del.onclick = function(){
                        console.log("删除");
                        // var dele = document.getElementsByClassName(".item_delete")
                        // var proID = this.getAttribute("data-id");
                        // var main_text = this.getAttribute("data-text");
                        // var data = {
                        //     annTitle : proID,
                        //     announcement : main_text
                        // }
                        console.log(newdata);
                        var str = JSON.stringify(newdata);
                        var xhr = new XMLHttpRequest();
                        xhr.open('post','/joinplat/boss/dropAnnouncement',true);
                        xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
                        xhr.withCredentials = true;
                        xhr.send(str);
                        // console.log(str);
                        xhr.onreadystatechange = function(){
                            if(xhr.readyState === 4 && xhr.status === 200){
                               var res = JSON.parse(xhr.responseText);
                               console.log(res);
                               if(res.code == 200){
                                   console.log(res.message);
                                   var el = document.createElement("div");
                                   el.setAttribute("class", "warningSuccess");
                                   el.innerText = "删除成功！";
                                   document.body.appendChild(el);
                                   el.classList.add("bounce-enter-active");
                                   // warningAll.style.display = 'block';
                                   setTimeout(() => {
                                       console.log("setTime");
                                       el.classList.remove("bounce-enter-active");
                                       el.classList.add("bounce-leave-active");
                                       // warningAll.style.display = 'none';
                                   }, 2000);
                               }else {
                                   console.log(res.message);
                                   var el = document.createElement("div");
                                   el.setAttribute("class", "warningSuccess");
                                   el.innerText = res.message;
                                   document.body.appendChild(el);
                                   el.classList.add("bounce-enter-active");
                                   // warningAll.style.display = 'block';
                                   setTimeout(() => {
                                       console.log("setTime");
                                       el.classList.remove("bounce-enter-active");
                                       el.classList.add("bounce-leave-active");
                                       // warningAll.style.display = 'none';
                                   }, 2000);
                               }
                            }
                            
                        }
                    }
                // }
                
            }
            else {
                console.log("展示失败");
                var el = document.createElement("div");
                el.setAttribute("class", "warningSuccess");
                el.innerText = res.message;
                document.body.appendChild(el);
                el.classList.add("bounce-enter-active");
                // warningAll.style.display = 'block';
                setTimeout(() => {
                    console.log("setTime");
                    el.classList.remove("bounce-enter-active");
                    el.classList.add("bounce-leave-active");
                    // warningAll.style.display = 'none';
                }, 2000);
            }
        }
    }
    // // 上传公告
    // var submit = document.getElementById('submit');
    // submit.onclick = function(){
    //     // let num_id = window.location.search.split("=")[1];
    //     var title = document.getElementById('annTitle').value;
    //     var div1 = document.getElementById('div1');
    //     console.log(div1);
    //     var content = document.getElementById('LAY_demo1').value;
    //     console.log(content);
    //     // var text = document.getElementsByClassName('.w-e-text')[0].value;
    //     // console.log(text);
    //     var root = {
    //         userAccount : 2022123,
    //         // userAccount : num_id,
    //         annTitle : title,
    //         announcement : content
    //     }
    //     console.log(root);
    //     var str = JSON.stringify(root);
    //     console.log(str);
    //     let xhr = new XMLHttpRequest();
    //     xhr.open('post','/joinplat/boss/from/update',true);
    //     xhr.setRequestHeader('Content-Type','application/json;charset=UTF-8');
    //     xhr.withCredentials = true;
    //     xhr.send(str);
    //     xhr.onreadystatechange = function(){
    //         if(xhr.status === 200){
    //             var res = JSON.parse(xhr.responseText);
    //             console.log(res);
    //             if(res.code == 200){
    //                 // alert("发布成功");
    //                 var el = document.createElement("div");
    //                 el.setAttribute("class", "warningSuccess");
    //                 el.innerText = "发布成功！";
    //                 document.body.appendChild(el);
    //                 el.classList.add("bounce-enter-active");
    //                 // warningAll.style.display = 'block';
    //                 setTimeout(() => {
    //                     console.log("setTime");
    //                     el.classList.remove("bounce-enter-active");
    //                     el.classList.add("bounce-leave-active");
    //                     // warningAll.style.display = 'none';
    //                 }, 2000);
                    
    //             }else {
    //                 // alert("发布失败");
    //                 var el = document.createElement("div");
    //                 el.setAttribute("class", "warningAll");
    //                 el.innerText = res.message;
    //                 document.body.appendChild(el);
    //                 el.classList.add("bounce-enter-active");
    //                 // warningAll.style.display = 'block';
    //                 setTimeout(() => {
    //                     console.log("setTime");
    //                     el.classList.remove("bounce-enter-active");
    //                     el.classList.add("bounce-leave-active");
    //                     // warningAll.style.display = 'none';
    //                 }, 2000);
    //             }
    //         }
    //     }
    // }
    

})