(function (window) {
    console.log("111");
    var defaultPager = {
        currentPage: 1, //现在页数
        limit: 10, //每页的数据个数
        divNumber: 5, //页码块的个数
        total: 0, //数据总数
        pageNumber: 0, //总页数
        year : 2022,
        jrFVolunte : ' '
    }

    function createPager(pager) {
        pager = Object.assign(defaultPager, pager)
        console.log(pager);
        request(pager);
        bindEvent(pager);
    }

    // 年份分类
    pYear = document.getElementById("year");
    pYear.onchange = function() {
        console.log(pYear.value);
        createPager();
        console.log("年份分类");
    } 

    // 志愿分类
    pVolunteer = document.getElementById("firstVolunter");
    pVolunteer.onchange = function() {
        console.log(pVolunteer.value);
        createPager();
        console.log("志愿分类");
    }

    function request(pager) {
        pager.year = document.getElementById("year").value;
        pager.jrFVolunte = document.getElementById("firstVolunter").value;
        console.log(pager.year);
        console.log(pager.jrFVolunte);
        console.log(1);
        var xhr = new XMLHttpRequest();
        xhr.open("get", `/joinplat/senior/getJuniors?year=${pager.year}&currentPage=${pager.currentPage}&pageSize=${pager.limit}&jrFVolunte=${pager.jrFVolunte}`, true)
        xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhr.withCredentials = true;
        xhr.send()
        xhr.onreadystatechange = function () {
            if (xhr.status === 200) {
                var res = xhr.responseText;
                console.log(res);
                var res = JSON.parse(xhr.responseText);
                // console.log(res);
                // console.log('3');
                console.log(res.totalData);
                if(res.totalData == 0) {
                    var showTable = document.getElementById('showTable');
                    var tpdata = "";
                    tpdata +=`
                        <h3>暂未找到相关信息</h3>
                    `;
                    showTable.innerHTML = tpdata;
                }
                else {
                    console.log(res.data.junior[0].jrName);
                    console.log(res.totalData);
                    var req = res.data;
                    console.log(req);
                    // if (res.code == 1) {
                    pager.total = res.totalData;
                    pager.pageNumber = Math.ceil(pager.total / pager.limit);
                    adddata(req);
                    show(pager);
                     // 每一行背景颜色不同
                    var trList = document.getElementsByTagName("tr");
                    var trListLength = trList.length;
                    console.log(trList);
                    // trList[0].style.backgroundColor = '#698B98';
                    trList[0].style.borderRadius = 20 + 'px';
                    for(i = 1; i < trListLength; i ++ ){
                        console.log(i);
                        trList[i].style.borderRadius = 20 + 'px';
                        if( i%2 == 0){
                            trList[i].style.backgroundColor = '#fcfcfc';
                        }else {
                            trList[i].style.backgroundColor = '#e0ecfa';
                        }
                    }
                    var bgc = 'white';
                    // mouseover事件
                    for(i = 1; i < trListLength; i ++){
                        var bgc = trList[i].style.backgroundColor;
                        console.log(bgc);
                        trList[i].onmouseover = function() {
                            if(i%2 != 0){
                                this.style.backgroundColor = '#bdd7f0';
                            }else {
                                this.style.backgroundColor = '#bdd7f0'
                            }
                        }
                        trList[i].onmouseleave = function() {
                            if(i%2 != 0){
                                this.style.backgroundColor = '#e0ecfa';
                            }else {
                                this.style.backgroundColor = '#fcfcfc'
                            }
                            
                        }
                    }
                    // }
                    
                }
                // else if (res.code == -1) {
                    //     alert('请先登录')
                    //     window.location.href = '../Login/login.html'
                    // }
            }
        }
    }

    // 渲染当前页面数据
    function adddata(res) {
        var tpdata = "";
        var dataHtml = "";
        tpdata +=`
            <tr>
                <th class = "num">序号</th>
                <th class = "name">姓名</th>
                <th class = "grade">年级</th>
                <th class = "profession">专业</th>
                <th class = "firstV">志愿一</th>
                <th class = "secondV">志愿二</th>
                <th class = "more">详情</th>
            </tr>  
        `;
        // for (let item of res.data.seller) {
            // console.log(item);
            // tpdata += `<li><img src = "${item.address}" alt=""><span>${item.name}</span><div class='pri'>￥${item.price}</div></li>`
        // }
        var showList = res.junior;
        console.log(showList);
        // <td>${showList[i].jrNum}</td>
        for (i = 0; i < showList.length; i++) {
            tpdata += `
                    <tr>
                        <td class = "num">${i+1}</td>
                        <td class = "name">${showList[i].jrName}</td>
                        <td class = "grade">${showList[i].jrGrade}</td>
                        <td class = "profession">${showList[i].jrProfession}</td>
                        <td class = "firstV">${showList[i].jrFVolunte}</td>
                        <td class = "secondV">${showList[i].jrSVolunte}</td>
                        <td class = "more"><a href="../showDetail/index.html?id=${showList[i].jrNum}">详情</a></td>
                    </tr> 
            `
        }
        var showTable = document.getElementById('showTable');
        showTable.innerHTML = tpdata;
    }

    // 展示页码框
    function show(pager) {
        var min, max
        min = pager.currentPage - Math.floor(pager.divNumber / 2)
        if (min < 1) {
            min = 1
        }
        max = min + pager.divNumber - 1
        if (max > pager.pageNumber) {
            max = pager.pageNumber
            min = max - pager.pageNumber + 1
        }
        if (pager.divNumber >= pager.pageNumber) {
            min = 1
            max = pager.pageNumber
        }
        var item = ""
        if (pager.currentPage != 1) {
            item += `<div class="first">首页</div>
            <div class="prev">上一页</div>`
        }
        if (min != 1) {
            item += `<div class="omit">...</div>`
        }
        for (var i = min; i <= max; i++) {
            var flag = ''
            if (i == pager.currentPage) {
                flag = 'selected'
            }
            item += `<div class="number ${flag}">${i}</div>`
        }
        if (max != pager.pageNumber) {
            item += `<div class="omit">...</div>`
        }
        if (pager.currentPage != pager.pageNumber) {
            item += `<div class="next">下一页</div>
            <div class="last">尾页</div>`
        }
        item += `<div>共${pager.pageNumber}页</div>`
        document.getElementById("pager").innerHTML = item
    }

    // 绑定事件
    function bindEvent(pager) {
        document.getElementById("pager").addEventListener("click", function (e) {
            var classlist = e.target.getAttribute('class')
            if (classlist.search("first") !== -1) {
                toPage(1, pager)
            } else if (classlist.search("prev") !== -1) {
                toPage(pager.currentPage - 1, pager)
            } else if (classlist.search("next") !== -1) {
                toPage(pager.currentPage + 1, pager)
            } else if (classlist.search("last") !== -1) {
                toPage(pager.pageNumber, pager)
            } else if (classlist.search("number") !== -1) {
                var targetPage = Number(e.target.innerText)
                toPage(targetPage, pager)
            }
        }, false)
    }

    // 跳转页面
    function toPage(page, pager) {
        if (page < 1) {
            page = 1
        }
        if (page > pager.pageNumber) {
            page = pager.pageNumber
        }
        if (page === pager.currentPage) {
            return
        }
        pager.currentPage = page
        request(pager)
    }

    createPager();
    var trList = document.getElementsByTagName("tr");
    var trListLength = trList.length;
    console.log(trList);
    trList[0].style.backgroundColor = '#34b0fe';
    trList[0].style.borderRadius = 20 + 'px';
    for(i = 1; i < trListLength; i ++ ){
        console.log(i);
        trList[i].style.borderRadius = 20 + 'px';
        if( i%2 == 0){
            trList[i].style.backgroundColor = '#fcfcfc';
        }else {
            trList[i].style.backgroundColor = '#e0ecfa';
        }
    }
   
})(window)