/*window.onload = function () {
    var data = {
        pageNum: 1,
    };
    var str = JSON.stringify(data);
    reque(str);
};
//这里并没有得到动态的pagenum
function reque(str) {
    var xhr = new XMLHttpRequest();
    xhr.open("post", "/Commodity/mainpageshow", true);
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhr.withCredentials = true;
    xhr.send(str);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var res = JSON.parse(xhr.responseText);
            if (res.code == 1) {
                var items = ""
                for (var i = 0; i < 8; i++) {
                    //定义需要拼接进去的字符串变量,将字符串变量用${}包起来，再写到需要拼接的地方
                    items += `
                    <li class="show-products-details">
                    <img src="${res.data[i].commodityphoto}">
                  
                    <div class="desc">${res.data[i].commodityname}</div>
                    <span class="price"><span>￥${res.data[i].commodityprice}</span></span>
                    <a href=products-details.html?commodityid=${res.data[i].commodityid}
                id="product-link" >详情页</a>
                    </li>
                    `
                }
                var addp = document.getElementById('addp');
                addp.innerHTML = items;
                  } else {
                alert(res.msg);
            }
        }
    };
}
*/
(function (window) {
    var defaultPager = {
        currentPage: 1, //现在页数
        limit: 8, //每页的数据个数
        divNumber: 8, //页码块的个数
        total: 0, //数据总数
        pageNumber: 0 //总页数
    }

    function createPager(pager) {
        pager = Object.assign(defaultPager, pager)
        console.log(pager);
        request(pager)
        bindEvent(pager)
    }

    function request(pager) {
        var data = {
            pageNum: pager.currentPage,

        };
        console.log(data);
        var str = JSON.stringify(data);
        console.log(1)
        var xhr = new XMLHttpRequest()
        xhr.open("post", '/Commodity/mainpageshow', true);
        xhr.withCredentials = true;
        xhr.send(str);

        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                var res = JSON.parse(xhr.responseText)
                console.log(res);
                pager.total = res.data.totalData;
                pager.pageNumber = Math.ceil(pager.total / pager.limit);
                adddata(res);
                show(pager);
            }
        }
    }

    // 渲染当前页面数据
    function adddata(res) {
        var tpdata = ""

        for (i = 0; i < res.data.length; i++) {
            // console.log(item);
            tpdata += `
            <li class="show-products-details">
            <img src="${res.data[i].commodityphoto}">
            <div class="desc">${res.data[i].commodityname}</div>
            <a href=products-details.html?commodityid=${res.data[i].commodityid} id="product-link" >详情页</a>
            <span class="price"><span>￥${res.data[i].commodityprice}</span></span>
            </li>
            `
        }
        // document.querySelector('.show').children[0].innerHTML = tpdata;
        var addp = document.getElementById('addp');
        addp.innerHTML = tpdata;


        // var ul = document.querySelector('ul');
        // console.log(ul.children.length)
        // for (var i = 0; i < ul.children.length; ++i) {
        //     ul.children[i].setAttribute('index', i)
        // }
        // for (var i = 0; i < ul.children.length; ++i) {
        //     ul.children[i].addEventListener('click', function () {
        //         var index = this.getAttribute('index');
        //         // console.log(index);
        //         console.log(data)
        //         window.location.href = '../index.html'; //这里需要修改一下数据，跳转到商品详情页
        //     })
        // }
    }

    // 展示页码框
    function show(pager) {
        var min, max
        min = pager.currentPage - Math.floor(pager.divNumber / 2)
        if (min < 1) {
            min = 1
        }
        max = min + pager.divNumber - 1
        if (max > pager.pageNumber) {
            max = pager.pageNumber
            min = max - pager.pageNumber + 1
        }
        if (pager.divNumber >= pager.pageNumber) {
            min = 1
            max = pager.pageNumber
        }
        var item = ""
        if (pager.currentPage != 1) {
            item += `<div class="first">首页</div>
            <div class="prev">上一页</div>`
        }
        if (min != 1) {
            item += `<div class="omit">...</div>`
        }
        for (var i = min; i <= max; i++) {
            var flag = ''
            if (i == pager.currentPage) {
                flag = 'selected'
            }
            item += `<div class="number ${flag}">${i}</div>`
        }
        if (max != pager.pageNumber) {
            item += `<div class="omit">...</div>`
        }
        if (pager.currentPage != pager.pageNumber) {
            item += `<div class="next">下一页</div>
            <div class="last">尾页</div>`
        }

        document.getElementById("pager").innerHTML = item
    }

    // 绑定事件
    function bindEvent(pager) {
        document.getElementById("pager").addEventListener("click", function (e) {
            var classlist = e.target.getAttribute('class')
            if (classlist.search("first") !== -1) {
                toPage(1, pager)
            } else if (classlist.search("prev") !== -1) {
                toPage(pager.currentPage - 1, pager)
            } else if (classlist.search("next") !== -1) {
                toPage(pager.currentPage + 1, pager)
            } else if (classlist.search("last") !== -1) {
                toPage(pager.pageNumber, pager)
            } else if (classlist.search("number") !== -1) {
                var targetPage = Number(e.target.innerText)
                toPage(targetPage, pager)
            }
        }, false)
    }

    // 跳转页面
    function toPage(page, pager) {
        if (page < 1) {
            page = 1
        }
        if (page > pager.pageNumber) {
            page = pager.pageNumber
        }
        if (page === pager.currentPage) {
            return
        }
        pager.currentPage = page
        request(pager)
    }


    window.createPager = createPager
})(window)