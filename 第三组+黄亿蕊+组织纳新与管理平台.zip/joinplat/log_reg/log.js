/*
    Logic：
        主要采用原生 JavaScript，
        只有在发送 Ajax 请求是才使用 JQuery
    
    ===
    1、登录注册页面的切换逻辑
    2、Ajax发送及接受响应逻辑
    ===
*/


// 封装选择器, 采用ES6箭头函数写法
const getSelector = ele => {
    return typeof ele === "string" ? document.querySelector(ele) : "";
}


// 登录注册载入

const containerShow = () => {
    var show = getSelector(".container")
    show.className += " container-show"
}


window.onload = containerShow;


// 登录注册页切换
((window, document) => {

    // 登录 -> 注册
    let toSignBtn = getSelector(".toSign"),
        toLoginBtn = getSelector(".toLogin")
    loginBox = getSelector(".login-box"),
        signBox = getSelector(".sign-box");

    toSignBtn.onclick = () => {
        loginBox.className += ' animate_login';
        signBox.className += ' animate_sign';
    }

    toLoginBtn.onclick = () => {
        loginBox.classList.remove("animate_login");
        signBox.classList.remove("animate_sign");
    }


})(window, document);

window.addEventListener("load", function() {
    
    var toSignBtn = document.getElementsByClassName('.toSign')[0];
    var toLoginBtn = document.getElementsByClassName(".tologin")[0];
    var loginBox = document.getElementsByClassName(".login-box")[0];
    var signBox = document.getElementsByClassName(".sign-box")[0];
    var container = document.getElementsByClassName(".container")[0];
    var loginUser = document.getElementById("login-user");

    // 提示用户名不为空
    loginUser.onblur = function() {
        var warnings = document.getElementById("loginName").children[2];
        if (loginUser.value == "") {
            warnings.style.display = 'block';
        } else {
            warnings.style.display = 'none';
        }
        console.log(loginUser.value);
    }
    var loginPwd = document.getElementById("login-password");

    // 提示密码不为空
    loginPwd.onblur = function() {
        var warnings = document.getElementById("loginPwd").children[2];
        if (loginPwd.value == "") {
            warnings.style.display = 'block';
        } else {
            warnings.style.display = 'none';
        }
    }

    // 提交登录
    var login = document.getElementById("Login");
    login.onclick = function() {
        var userAccount = document.getElementById("login-user").value;
        var userPassword = document.getElementById("login-password").value;
        var userName = true;
        var userPwd = true;
        if (userAccount == "") {
            userName = false;
        }
        if (userPassword == "") {
            userPwd = false;
        }
        var warningLog = document.getElementsByClassName("warningLog")[0];
        if (userName === false || userPwd === false) {
            // warningLog.style.display = 'block';
            var el = document.createElement("div");
            el.setAttribute("class", "warningLog");
            el.innerText = "您未完整填写内容！";
            document.body.appendChild(el);
            el.classList.add("bounce-enter-active");
            // warningAll.style.display = 'block';
            setTimeout(() => {
                console.log("setTime");
                el.classList.remove("bounce-enter-active");
                el.classList.add("bounce-leave-active");
                // warningAll.style.display = 'none';
            }, 2000);
        }
        // else {
        // warningLog.style.display = 'none';
        // }
        let root = {
            userAccount: userAccount,
            userPassword: userPassword
        }
        console.log(root);
        var str = JSON.stringify(root);
        console.log(str);
        let xhr = new XMLHttpRequest();
        // xhr.responseType = 'json';
        xhr.open('post', '/joinplat/community/login', true);
        xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
        xhr.withCredentials = true;
        xhr.send(str);
        xhr.onreadystatechange = function() {
            if (xhr.status === 200) {
                var res = JSON.parse(xhr.responseText);
                console.log(res);
                console.log(res.code);
                if (res.code == 200) {
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningSuccess");
                    el.innerText = "登录成功，你将进入JOIN大家庭！";
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 2000);
                    var cookie = window.document.cookie;
                    console.log(window.document.cookie);
                    console.log(res);
                    if (res.data.user.userState == 1) {
                        window.location.href = '../shouye/index.html?userState=' + res.userState;
                    } else if (res.data.user.userState == 2) {
                        window.location.href = '../membershow/index.html?userState=' + res.userState;
                    } else if (res.data.user.userState == 3) {
                        window.location.href = '../uncontrol/control.html?userState=' + res.userState;
                    }
                } else {
                    // alert("登陆失败")
                    // var warningAll = document.getElementsByClassName("warningAll")[0];
                    // warningAll.style.display = 'block';
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningAll");
                    el.innerText = res.message;
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 2000);
                }
            }
        }
    }
    var register = document.getElementById("register");

    // 判断用户名是否为空
    var username = document.getElementById("sign-user");
    username.addEventListener("blur", function() {
        console.log("username change!");
        console.log(username.value);
        var warnings = document.getElementById("signUser").children[2];
        if (username.value == "") {
            console.log(username.value);
            warnings.style.display = 'block';
        } else {
            console.log("username.value");
            warnings.style.display = 'none';
        }
    })

    // 判断学号是否填写
    var usercnt = document.getElementById("sign-account");
    usercnt.onblur = function() {
        console.log("account change");
        var warnings = document.getElementById("signAccount").children[2];
        if (usercnt.value == "") {
            warnings.style.display = 'block';
        } else {
            warnings.style.display = 'none';
        }
    }

    // 判断密码是否为空
    var userpwd = document.getElementById("sign-password");
    userpwd.onblur = function() {
        console.log("pwd change");
        var warnings = document.getElementById("signPwd").children[2];
        if (userpwd.value == "") {
            warnings.style.display = 'block';
        } else {
            warnings.style.display = 'none';
        }

    }

    // 确认密码
    var userpwdAc = document.getElementById("sign-password-accept");
    userpwdAc.onblur = function() {
        console.log("pwd again");
        var warnings = document.getElementById("signPwdAccept").children[2];
        var userpwd = document.getElementById("sign-password");
        console.log(userpwdAc.value, userpwd.value);
        if (userpwdAc.value != userpwd.value) {
            warnings.style.display = 'block';
        } else {
            warnings.style.display = 'none';
        }
    }

    // 判断邮箱是否符合规范
    var userel = document.getElementById("sign-email");
    userel.onchange = function() {
        regex = /^([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/;
        var warnings = document.getElementById("signEmail").children[2];
        if (!userel.value.match(regex)) {
            warnings.style.display = 'block';
        } else {
            warnings.style.display = 'none';
        }
    }

    // 发送邮箱验证码
    var getcode = document.getElementById('getcode');
    console.log(getcode);
    getcode.onclick = function() {
        console.log("click button");
        var signEmail = document.getElementById('sign-email').value;
        var root = {
            userEmail: signEmail
        }
        console.log(root);
        var str = JSON.stringify(root);
        console.log(str);
        let xhr = new XMLHttpRequest();
        // xhr.responseType = 'json';
        xhr.open('post', '/joinplat/community/tourist', true);
        xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
        xhr.withCredentials = true;
        xhr.send(str);
        xhr.onreadystatechange = function() {
            if (xhr.status === 200) {
                var res = JSON.parse(xhr.responseText);
                console.log(res);
                if (res.data == 200) {
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningSuccess");
                    el.innerText = "发送成功，请查看邮箱！";
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 2000);
                } else {
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningAll");
                    el.innerText = res.message;
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 2000);
                }
            }
        }
    }


    // 判断电话号码是否符合规范
    // var userphone = document.getElementById("sign-phone");
    // userphone.onchange = function() {
    //     var regex =  '(^(\d{3,4}-)?\d{7,8})$|(13[0-9]{9})';
    //     var warnings = document.getElementById("signPhone").children[2];
    //     if(!userphone.value.match(regex)){
    //         warnings.style.display = 'block';
    //     }else {
    //         warnings.style.display = 'none';
    //     }
    //     var signPhone = document.getElementById("signPhone");
    // }


    // 注册提交
    register.onclick = function() {
        console.log("register");
        var userName = true;
        var userPwd = true;
        var username = document.getElementById("sign-user");
        if (username.value == "") {
            userName = false;
        } else {
            userName = true;
        }
        var userpwd = document.getElementById("sign-password");
        var userpwdAc = document.getElementById("sign-password-accept");
        if (userpwd.value == "" || userpwdAc.value == "" || userpwdAc.value != userpwd.value) {
            userPwd = false;
        } else {
            userPwd = true;
        }
        console.log(userName, userPwd);
        var warningReg = document.getElementsByClassName("warningReg")[0];
        if (userName === false || userPwd === false) {
            console.log("warning");
            warningReg.style.display = 'block';
        } else {
            warningReg.style.display = 'none';
        }
        var sign_user = document.getElementById("sign-user").value;
        var sign_password = document.getElementById("sign-password").value;
        var sign_account = document.getElementById("sign-account").value;
        // 性别
        // var sex = document.getElementsByName("sex");
        // let sign_sex = '男'
        // for(var  i = 0;i<sex.length;i++){
        //     if(sex[i].checked == true){
        //          sign_sex = sex[i].value;
        //     }
        // }
        // 电话
        // var sign_phone = document.getElementById("sign-phone").value;
        var sign_email = document.getElementById("sign-email").value;
        var sign_code = document.getElementById('code').value;
        let root = {
            userName: sign_user,
            userPassword: sign_password,
            userEmail: sign_email,
            // userPhone : sign_phone,
            // userGender : sign_sex,
            // 邮箱验证码
            code: sign_code,
            userAccount: sign_account
        }
        console.log(root);
        var str = JSON.stringify(root);
        console.log(str);
        let xhr = new XMLHttpRequest();
        // xhr.responseType = 'json';
        //http://localhost:8080/community/registered
        xhr.open('post', '/joinplat/community/registered', true);
        xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
        xhr.withCredentials = true;
        xhr.send(str);
        xhr.onreadystatechange = function() {
            if (xhr.status === 200) {
                var res = JSON.parse(xhr.responseText);
                console.log(res);
                if(res.code == 200) {
                    // alert("注册成功");
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningSuccess");
                    el.innerText = "注册成功！";
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 2000);
                }else {
                    // alert("注册失败");
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningRegister");
                    el.innerText = res.message;
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 2000);
                }
            } else {
                // alert("注册失败");
                var el = document.createElement("div");
                el.setAttribute("class", "warningRegister");
                el.innerText = res.message;
                document.body.appendChild(el);
                el.classList.add("bounce-enter-active");
                // warningAll.style.display = 'block';
                setTimeout(() => {
                    console.log("setTime");
                    el.classList.remove("bounce-enter-active");
                    el.classList.add("bounce-leave-active");
                    // warningAll.style.display = 'none';
                }, 2000);
            }
        }
    }
})