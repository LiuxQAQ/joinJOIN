window.addEventListener("load",function() {
    console.log("111");
    var signUpBtn = document.getElementById("signUp");
    var signInBtn = document.getElementById("signIn");
    var FormOne = document.getElementById("from1");
    var FormTwo = document.getElementById("from2");
    var container = document.querySelector(".container");
    signInBtn.onclick = function () {
        console.log("333");
        container.classList.remove("right-panel-active");
    }
    signUpBtn.onclick = function () {
        console.log("22");
        container.classList.add("right-panel-active");
    }
    FormOne.submit = function(e) {
        e.preventDefault();
    }
    FormTwo.submit = function(e) {
        e.preventDefault();
    } 
    var register = document.getElementById('register');
    var sign_user = document.getElementById('sign-user');
    var rname_false = document.getElementById('rname-false');
    var rname_right = document.getElementById('rname-right');
    sign_user.onblur = function() {
        console.log("on");
        if(sign_user.value == ""){
            rname_right.style.display = 'none';
            rname_false.style.display = 'block';
        }else {
            rname_false.style.display = 'none';
            rname_right.style.display = 'block';
        }
    }
    var sign_account = document.getElementById('sign-account');
    var raccount_false = document.getElementById('raccount-false');
    var raccount_right = document.getElementById('raccount-right');
    sign_account.onblur = function() {
        console.log("on");
        if(sign_account.value == ""){
            raccount_right.style.display = 'none';
            raccount_false.style.display = 'block';
        }else {
            raccount_false.style.display = 'none';
            raccount_right.style.display = 'block';
        }
    }
    var sign_password = document.getElementById('sign-password');
    var rpwd_false = document.getElementById('rpwd-false');
    var rpwd_right = document.getElementById('rpwd-right');
    sign_password.onblur = function() {
        console.log("on");
        if(sign_password.value == ""){
            rpwd_right.style.display = 'none';
            rpwd_false.style.display = 'block';
        }else {
            rpwd_false.style.display = 'none';
            rpwd_right.style.display = 'block';
        }
    }
    var sign_password_accept = document.getElementById('sign-password-accept');
    var rpwda_false = document.getElementById('rpwda-false');
    var rpwda_right = document.getElementById('rpwda-right');
    sign_password_accept.onblur = function() {
        console.log("on");
        if(sign_password_accept.value != sign_password.value){
            rpwda_right.style.display = 'none';
            rpwda_false.style.display = 'block';
        }else {
            rpwda_false.style.display = 'none';
            rpwda_right.style.display = 'block';
        }
    }
    var sign_email = document.getElementById('sign-email');
    var rema_false = document.getElementById('rema-false');
    var rema_right = document.getElementById('rema-right');
    sign_email.onchange = function() {
        console.log("on");
        regex = /^([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/;
        if(!sign_email.value.match(regex)){
            rema_right.style.display = 'none';
            rema_false.style.display = 'block';
        }else {
            rema_false.style.display = 'none';
            rema_right.style.display = 'block';
        }
    }
    var code = document.getElementById('code');
    var rcode_false = document.getElementById('rcode-false');
    var rcode_right = document.getElementById('rcode-right');
    code.onblur = function() {
        console.log("on");
        if(code.value == ""){
            rcode_right.style.display = 'none';
            rcode_false.style.display = 'block';
        }else {
            rcode_false.style.display = 'none';
            rcode_right.style.display = 'block';
        }
    }
    // 获取验证码
    var t;
    var getcode = document.getElementById('getcode');
    getcode.onclick = function(e) {
        var signemail = document.getElementById('sign-email').value;
        var regex = /^([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/;
        if(!signemail.match(regex)){
            var el = document.createElement("div");
            el.setAttribute("class", "warningAll");
            el.innerText = "邮箱有误，请重填！";
            document.body.appendChild(el);
            el.classList.add("bounce-enter-active");
            setTimeout(() => {
                console.log("setTime");
                el.classList.remove("bounce-enter-active");
                el.classList.add("bounce-leave-active");
            }, 3000);
        }else {
            var signEmail = document.getElementById('sign-email').value;
            var root = {
                userEmail: signEmail
            }
            console.log(root);
            var str = JSON.stringify(root);
            console.log(str);
            let xhr = new XMLHttpRequest();
            xhr.open('post','/joinplat/community/tourist', true);
            xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
            xhr.withCredentials = true;
            xhr.send(str);
            xhr.onreadystatechange = function() {
                if (xhr.status === 200) {
                    var res = JSON.parse(xhr.responseText);
                    console.log(res);
                    if (res.data == 200) {
                        var el = document.createElement("div");
                        el.setAttribute("class", "warningSuccess");
                        el.innerText = "发送成功，请查看邮箱！";
                        document.body.appendChild(el);
                        el.classList.add("bounce-enter-active");
                        setTimeout(() => {
                            console.log("setTime");
                            el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        }, 2000);
                    } else {
                        var el = document.createElement("div");
                        el.setAttribute("class", "warningAll");
                        el.innerText = res.message;
                        document.body.appendChild(el);
                        el.classList.add("bounce-enter-active");
                        setTimeout(() => {
                            console.log("setTime");
                            el.classList.remove("bounce-enter-active");
                            el.classList.add("bounce-leave-active");
                        }, 2000);
                    }
                }
            }
            t = setInterval(function () {
                countdown(e)
            },1000)
            countdown(e);
        }
    }
    var time = 60 ; 
    function countdown(e) {
        if(time == 0){
            document.getElementById("getcode").innerText = "获取验证码";
            time = 60;
            clearInterval(t);
        }else {
            document.getElementById("getcode").innerText = "重新发送"+time;
            time--;
        }
    }
    // 注册提交信息
    register.onclick = function () {
        var signName = sign_user.value;
        var signAccount = sign_account.value;
        var signPwd = sign_password.value;
        var signPwd1 = sign_password_accept.value;
        var signEmail = sign_email.value;
        var signCode = code.value;
        if(signName =="" || signAccount == "" || signCode =="" || signEmail == "" || signPwd == "" || signPwd1 != signPwd){
            var el = document.createElement("div");
            el.setAttribute("class", "warningAll");
            el.innerText = "请将注册信息填写完毕！";
            document.body.appendChild(el);
            el.classList.add("bounce-enter-active");
            setTimeout(() => {
                console.log("setTime");
                el.classList.remove("bounce-enter-active");
                el.classList.add("bounce-leave-active");
            }, 3000);
        }else {
            var root = {
                userName: signName,
                userPassword: signPwd,
                userEmail: signEmail,
                code: signCode,
                userAccount: signAccount,
                userPhone:13743434985
            }
            console.log(root);
            var str = JSON.stringify(root);
            console.log(str);
            let xhr = new XMLHttpRequest();
            xhr.open('post', '/joinplat/community/registered', true);
            xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
            xhr.withCredentials = true;
            xhr.send(str);
            xhr.onreadystatechange = function() {
                if (xhr.status === 200) {
                    var res = JSON.parse(xhr.responseText);
                    console.log(res);
                    if(res.code == 200) {
                        var el = document.createElement("div");
                        el.setAttribute("class", "warningSuccess");
                        el.innerText = "注册成功！";
                        document.body.appendChild(el);
                        el.classList.add("bounce-enter-active");
                        setTimeout(() => {
                            console.log("setTime");
                            el.classList.remove("bounce-enter-active");
                            el.classList.add("bounce-leave-active");
                        }, 2000);
                    }else {
                        // alert("注册失败");
                        var el = document.createElement("div");
                        el.setAttribute("class", "warningAll");
                        el.innerText = res.message;
                        document.body.appendChild(el);
                        el.classList.add("bounce-enter-active");
                        // warningAll.style.display = 'block';
                        setTimeout(() => {
                            console.log("setTime");
                            el.classList.remove("bounce-enter-active");
                            el.classList.add("bounce-leave-active");
                            // warningAll.style.display = 'none';
                        }, 2000);
                    }
                } else {
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningAll");
                    el.innerText = res.message;
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                    }, 2000);
                }
            }
        }
    }


    var login = document.getElementById('logBtn');
    var login_user = document.getElementById('login-user');
    var login_password = document.getElementById('login-password');
    var uname_false = document.getElementById('uname-false');
    var uname_right = document.getElementById('uname-right');
    var upwd_false = document.getElementById('upwd-false');
    var upwd_right = document.getElementById('upwd-right');
    login_user.onblur = function() {
        console.log("on");
        if(login_user.value == ""){
            uname_right.style.display = 'none';
            uname_false.style.display = 'block';
        }else {
            uname_false.style.display = 'none';
            uname_right.style.display = 'block';
        }
    }
    login_password.onblur = function() {
        console.log("on");
        if(login_password.value == ""){
            upwd_right.style.display = 'none';
            upwd_false.style.display = 'block';
        }else {
            upwd_false.style.display = 'none';
            upwd_right.style.display = 'block';
        }
    }
    var logBtn = document.getElementById("logBtn");
    logBtn.onclick = function() {
        var logName = login_user.value;
        var logPwd = login_password.value;
        if(logName == "" || logPwd == ""){
            var el = document.createElement("div");
            el.setAttribute("class", "warningAll");
            el.innerText = "请将注册信息填写完毕！";
            document.body.appendChild(el);
            el.classList.add("bounce-enter-active");
            // warningAll.style.display = 'block';
            setTimeout(() => {
                console.log("setTime");
                el.classList.remove("bounce-enter-active");
                el.classList.add("bounce-leave-active");
            // warningAll.style.display = 'none';
            }, 3000);
        }else {
            let root = {
                userAccount: logName,
                userPassword: logPwd
            }
            console.log(root);
            var str = JSON.stringify(root);
            console.log(str);
            let xhr = new XMLHttpRequest();
            // xhr.responseType = 'json';
            xhr.open('post', '/joinplat/community/login', true);
            xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
            xhr.withCredentials = true;
            xhr.send(str);
            xhr.onreadystatechange = function() {
                if (xhr.status === 200) {
                    var res = JSON.parse(xhr.responseText);
                    console.log(res);
                    console.log(res.code);
                    if (res.code == 200) {
                        var el = document.createElement("div");
                        el.setAttribute("class", "warningSuccess");
                        el.innerText = "登录成功，你将进入JOIN大家庭！";
                        document.body.appendChild(el);
                        el.classList.add("bounce-enter-active");
                        // warningAll.style.display = 'block';
                        setTimeout(() => {
                            console.log("setTime");
                            el.classList.remove("bounce-enter-active");
                            el.classList.add("bounce-leave-active");
                            // warningAll.style.display = 'none';
                        }, 3000);
                        // var cookie = window.document.cookie;
                        // console.log(window.document.cookie);
                        console.log(res);
                        if (res.data.user.userState == 1) {
                            window.location.href = '../shouye/index.html?userState=' + res.userState;
                        } else if (res.data.user.userState == 2) {
                            window.location.href = '../membershow/index.html?userState=' + res.userState;
                        } else if (res.data.user.userState == 3) {
                            window.location.href = '../uncontrol/control.html?userState=' + res.userState;
                        }
                    } else {
                        // alert("登陆失败")
                        // var warningAll = document.getElementsByClassName("warningAll")[0];
                        // warningAll.style.display = 'block';
                        var el = document.createElement("div");
                        el.setAttribute("class", "warningAll");
                        el.innerText = res.message;
                        document.body.appendChild(el);
                        el.classList.add("bounce-enter-active");
                        // warningAll.style.display = 'block';
                        setTimeout(() => {
                            console.log("setTime");
                            el.classList.remove("bounce-enter-active");
                            el.classList.add("bounce-leave-active");
                            // warningAll.style.display = 'none';
                        }, 3000);
                    }
                }
            }
        }
    }
},false);
// 函数中的参数为 要获取的cookie键的名称。

