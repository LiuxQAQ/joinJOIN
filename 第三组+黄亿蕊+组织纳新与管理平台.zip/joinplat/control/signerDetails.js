window.onload = function request() {
        function getnum(variable) {
        var query = window.location.search.substring(1);
        var vars = query.split("&");
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split("=");
            if (pair[0] == variable) return pair[1];
        }
    }
    urlid = getnum("id");
    urlnum = getnum("jrNum");

    var xhr = new XMLHttpRequest();
    var data = {
        jrId: urlid,
        jrNum: urlnum
    }
    var str = JSON.stringify(data);
    xhr.open('post', '/joinplat/boss/getJunior', true);
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhr.withCredentials = true;
    xhr.send(str);
    xhr.onreadystatechange = function() {
        if (xhr.status === 200) {
            var res = JSON.parse(xhr.responseText);
            console.log(res.code);
            var showList = res.data;
            console.log(showList);
            console.log(showList.junior[0].comments.length);
            if (res.code == 211) {
                var el = document.createElement("div");
                el.setAttribute("class", "warningAll");
                el.innerText = res.message;
                document.body.appendChild(el);
                el.classList.add("bounce-enter-active");
                // warningAll.style.display = 'block';
                setTimeout(() => {
                    console.log("setTime");
                    el.classList.remove("bounce-enter-active");
                    el.classList.add("bounce-leave-active");
                    // warningAll.style.display = 'none';
                }, 2000);
                window.location.href = '../log_reg/newlog.html'
            }
            if (res.code == 200) {

                var show = "";
                var showTable = document.getElementById('showTab');
                show += `
                <div id="showTab">
                <h1>报名表详细信息</h1>
                <div id="jrName">${showList.junior[0].jrName}</div>
                <div class="triangle"></div>
                <div id="jrfVol">志愿一：${showList.junior[0].jrFVolunte}</div>
                <div id="jrsVol">志愿二：${showList.junior[0].jrSVolunte}</div>
                <div id="basic">
                   
                    <div id="info">
                        <div class="title">个人信息</div>
                        <div class="triangleT"></div>
                        <div id="detail">
                            <ul>
                                <li>性别：${showList.junior[0].jrSex}</li>
                                <li>年级：${showList.junior[0].jrGrade}</li>
                                <li>专业：${showList.junior[0].jrProfession}</li>
                                <li>电话：${showList.junior[0].jrPhone}</li>
                                <li>邮箱：${showList.junior[0].jrEmail}</li>
                            </ul>
                        </div>
                        <div class="title">发送通知</div>
                        <div class="triangleT"></div>
                        <input type="text" id="inputtime" placeholder="请输入面试时间">
                        <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" id="faceto">
                        发送通知
                        </button>
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog" id="shang">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                        &times;
                                    </button>
                                    <h4 class="modal-title" id="myModalLabel">
                                        发送面试通知
                                    </h4>
                                </div>
                                <div class="modal-body">
                                    您确定发送面试通知吗
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">关闭
                                    </button>
                                    <button type="button" class="btn btn-primary" data-dismiss="modal" id="facetoface">
                                        面试确定
                                    </button>
                                </div>
                            </div>
                            <!-- /.modal-content -->
                        </div>
                        </div>
                        <select id="inputsubject">
                                                <option value="前端">前端</option>
                                                <option value="后端">后端</option>
                                                <option value="产品">产品</option>
                                            </select>
                                            <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#MyModal" id="success">
                                            录取通知
                                            </button>
                                            <div class="modal fade" id="MyModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                            &times;
                                                        </button>
                                                            <h4 class="modal-title" id="myModalLabel">
                                                                发送录取通知
                                                            </h4>
                                                        </div>
                                                        <div class="modal-body" >
                                                            您确定发送录取通知吗
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-default" data-dismiss="modal">关闭
                                                        </button>
                                                            <button type="button" class="btn btn-primary" data-dismiss="modal" id="successin">
                                                            录取确定
                                                        </button>
                                                        </div>
                                                    </div>
                                                    <!-- /.modal-content -->
                                                </div>
                                                <!-- /.modal -->
                                            </div>
                    </div>
                </div>
                <div id="more">
                    <div id="introduce">
                        <div class="title">个人介绍</div><div class="triangleT"></div>
                        <div class="write">
                            ${showList.junior[0].jrIntroduct}
                        </div>
                    </div>
                    <div id="understanding">
                        <div class="title">部门理解</div><div class="triangleT"></div>
                        <div class="write">
                            ${showList.junior[0].jrUnderst}
                        </div>
                    </div>
                    <div id="prize">
                        <div class="title">获奖情况</div><div class="triangleT"></div>
                        <div class="write">
                            ${showList.junior[0].jrExperien}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
         `;
                showTable.innerHTML = show;
                var commentshow = document.getElementById('commentshow');
                var tbody1 = "";

                for (i = 0; i < showList.junior[0].communitys.length; i++) {
                    console.log()
                    tbody1 += `
                    <tr>
                    <td>${showList.junior[0].communitys[i].userName}</td>
                    <td>${showList.junior[0].comments[i].grade}</td>
                    <td>${showList.junior[0].comments[i].ctComment}</td>
                    </tr>
                    `
                }
                commentshow.innerHTML = tbody1
                console.log(showList);
                var facetoface = document.getElementById('facetoface');
                facetoface.onclick = function() {
                    console.log("面试通知按钮启动");
                    var inputtime = document.getElementById('inputtime');
                    var facetime = inputtime.value;
                    var data = {
                        jrEmail: showList.junior[0].jrEmail,
                        jrName: showList.junior[0].jrName,
                        time: facetime
                    }
                    var str = JSON.stringify(data);
                    var xhr = new XMLHttpRequest();
                    xhr.open("post", "/joinplat/senior/send/noticeEmail", true);
                    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
                    xhr.withCredentials = true;
                    xhr.send(str);
                    xhr.onreadystatechange = function() {
                        if (xhr.status === 200) {
                            var res = JSON.parse(xhr.responseText);
                            if (res.code == 200) {
                                // alert(res.msg);
                                var el = document.createElement("div");
                                el.setAttribute("class", "warningSuccess");
                                el.innerText = res.message;
                                document.body.appendChild(el);
                                el.classList.add("bounce-enter-active");
                                // warningAll.style.display = 'block';
                                setTimeout(() => {
                                    console.log("setTime");
                                    el.classList.remove("bounce-enter-active");
                                    el.classList.add("bounce-leave-active");
                                    // warningAll.style.display = 'none';
                                }, 3000);
                            } else {
                                var el = document.createElement("div");
                                el.setAttribute("class", "warningAll");
                                el.innerText = res.message;
                                document.body.appendChild(el);
                                el.classList.add("bounce-enter-active");
                                // warningAll.style.display = 'block';
                                setTimeout(() => {
                                    console.log("setTime");
                                    el.classList.remove("bounce-enter-active");
                                    el.classList.add("bounce-leave-active");
                                    // warningAll.style.display = 'none';
                                }, 3000);
                                window.location.href = '../log_reg/newlog.html'
                            }
                        }
                    }
                }
                var successin = document.getElementById('successin');
                successin.onclick = function() {
                        console.log('录取按钮启动');
                        var subject = document.getElementById('inputsubject').value;
                        console.log(showList.junior[0].jrName);
                        console.log(subject);
                        var data = {
                            jrNum: urlnum,
                            jrName: showList.junior[0].jrName,
                            jrEmail: showList.junior[0].jrEmail,
                            job: subject,
                            jrState: 1
                                // 其中1表示录取，0表示不录取
                        }
                        var str = JSON.stringify(data);
                        console.log(str);
                        var xhr = new XMLHttpRequest();
                        xhr.open("post", "/joinplat/senior/send/passEmail", true);
                        xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
                        xhr.withCredentials = true;
                        xhr.send(str);
                        xhr.onreadystatechange = function() {
                            if (xhr.status === 200) {
                                var res = JSON.parse(xhr.responseText);
                                console.log(res);
                                console.log(res.code);
                                if (res.code == 200) {
                                    var el = document.createElement("div");
                                    el.setAttribute("class", "warningSuccess");
                                    el.innerText = res.message;
                                    document.body.appendChild(el);
                                    el.classList.add("bounce-enter-active");
                                    // warningAll.style.display = 'block';
                                    setTimeout(() => {
                                        console.log("setTime");
                                        el.classList.remove("bounce-enter-active");
                                        el.classList.add("bounce-leave-active");
                                        // warningAll.style.display = 'none';
                                    }, 2000);
                                    // alert(res.msg);
                                } else {
                                    var el = document.createElement("div");
                                    el.setAttribute("class", "warningAll");
                                    el.innerText = res.message;
                                    document.body.appendChild(el);
                                    el.classList.add("bounce-enter-active");
                                    // warningAll.style.display = 'block';
                                    setTimeout(() => {
                                        console.log("setTime");
                                        el.classList.remove("bounce-enter-active");
                                        el.classList.add("bounce-leave-active");
                                        // warningAll.style.display = 'none';
                                    }, 3000);
                                }
                            }
                        }
                    }
                    // 这里发不录取通知
            }
        }
    }
}