window.addEventListener("load", function() {
    console.log("1111");
    let num_id = this.location.search.split("=")[1];
    var data = {
        jrNum: num_id
    }
    var str = JSON.stringify(data);
    console.log(num_id);
    var xhr = new XMLHttpRequest();
    // ?jrId=num_id
    xhr.open('post', link + '/joinplat/senior/getJunior', true);
    xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
    xhr.withCredentials = true;
    xhr.send(str);
    xhr.onreadystatechange = function() {
            if (xhr.status === 200) {
                console.log(xhr.responseText);
                var res = JSON.parse(xhr.responseText);
                var showList = res.data.junior;
                console.log(showList);
                if (res.code == 211) {
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningRegister");
                    el.innerText = res.message;
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 2000);
                    window.location.href = '../log_reg/newlog.html'
                }
                if (res.code == 200) {
                    var show = "";
                    var showTable = document.getElementById('show');
                    show += `
                <div id="showTab">
                <h1>报名表详细信息</h1>
                <div id="one">
                    <div id="jrName">${showList.jrName}</div>
                    <div class="triangle"></div>
                    <div id="jrfVol">志愿一：${showList.jrFVolunte}</div>
                    <div id="jrsVol">志愿二：${showList.jrSVolunte}</div>
                </div>
                <div id="basic">
                    <div id="photo">
                        <img src="/joinplat/${showList.jrPhoto}" alt="">
                    </div>
                    <div id="info">
                        <div class="title">个人信息</div><div class="triangleT"></div>
                        <div id="detail">
                            <ul>
                                <li>性别：${showList.jrSex}</li>
                                <li>年级：${showList.jrGrade}</li>
                                <li>专业：${showList.jrProfession}</li>
                                <li>生日：${showList.jrBirthday}</li>
                                <li>电话：${showList.jrPhone}</li>
                                <li>邮箱：${showList.jrEmail}</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div id="more">
                    <div id="introduce">
                        <div class="title">个人介绍</div><div class="triangleT"></div>
                        <div class="write">
                            ${showList.jrIntroduct}
                        </div>
                    </div>
                    <div id="understanding">
                        <div class="title">部门理解</div><div class="triangleT"></div>
                        <div class="write">
                            ${showList.jrUnderst}
                        </div>
                    </div>
                    <div id="prize">
                        <div class="title">获奖情况</div><div class="triangleT"></div>
                        <div class="write">
                            ${showList.jrExperien}
                        </div>
                    </div>
                </div>
                
                `;

                    showTable.innerHTML = show;
                }
            }
        }
        // 提交评论
    var sub_comment = document.getElementById("sub_comment");
    sub_comment.onclick = function() {
        var ol = document.getElementById("commentOl");
        var List = ol.children;
        console.log(List.length);
        var partList = document.getElementsByName("part");
        console.log(partList);
        // 获取评论建议的部门
        var part = "前端";
        for (var i = 0; i < partList.length; i++) {
            if (partList[i].checked == 1) {
                part = partList[i].value;
                console.log(partList[i].value);
            }
        }
        var resultList = document.getElementsByName("result");
        console.log(resultList);
        // 获取评论的标准
        var result = "及格";
        for (var i = 0; i < resultList.length; i++) {
            if (resultList[i].checked == 1) {
                result = resultList[i].value;
                console.log(resultList[i].value);
            }
        }
        var markList = document.getElementsByName("mark");
        console.log(markList);
        // 获取评论的分数
        var mark = "3";
        for (var i = 0; i < markList.length; i++) {
            if (markList[i].checked == 1) {
                mark = markList[i].value;
                console.log(markList[i].value);
            }
        }
        var jr_comment = document.getElementById("jr_comment");
        var jr_comments = document.getElementById("jr_comment").value;
        jr_comment.onkeyup = function() {
            console.log("textarea");
                var tValue = this.value;
                // console.log(tValue);
                console.log(tValue.length,"keyup");
                var maxLength = 30;
                var lessToWrite = maxLength - tValue.length;
                if(tValue.length > maxLength) {
                    // alert("超过限制数字");
                    // var showT = tValue.substring(0,200)
                    // console.log(showT);
                    this.value = tValue.substring(0,30);
                }else {
                    var in1 = document.getElementById("in1");
                    in1.style.width = 130 + 'px';
                    in1.innerText = "还可以写"+lessToWrite+"个字";
                }
        }
        jr_comment.onkeydown = function() {
            console.log("textarea");
                var tValue = this.value;
                // console.log(tValue);
                console.log(tValue.length,"kepdown");
                var maxLength = 30;
                var lessToWrite = maxLength - tValue.length;
                if(tValue.length > maxLength) {
                    // alert("超过限制数字");
                    // var showT = tValue.substring(0,200)
                    // console.log(showT);
                    this.value = tValue.substring(0,30);
                }else {
                    var in1 = document.getElementById("in1");
                    in1.style.width = 130 + 'px';
                    in1.innerText = "还可以写"+lessToWrite+"个字";
                }
        }
    
        jr_comment.onchange = function() {
            console.log("textarea");
                var tValue = this.value;
                // console.log(tValue);
                console.log(tValue.length,"change");
                var maxLength = 30;
                var lessToWrite = maxLength - tValue.length;
                if(tValue.length > maxLength) {
                    // alert("超过限制数字");
                    // var showT = tValue.substring(0,200)
                    // console.log(showT);
                    this.value = tValue.substring(0,30);
                }else {
                    var in1 = document.getElementById("in1");
                    in1.style.width = 130 + 'px';
                    in1.innerText = "还可以写"+lessToWrite+"个字";
                }
        }
        let data = {
            jrId: num_id,
            grade: mark,
            department: part,
            appraise: result,
            ctComment: jr_comments
        }
        var str = JSON.stringify(data);
        console.log(str);
        var xhr = new XMLHttpRequest();
        xhr.open('post', link + '/joinplat/senior/addComment', true);
        xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
        xhr.withCredentials = true;
        xhr.send(str);
        xhr.onreadystatechange = function() {
            if (xhr.status === 200) {
                console.log(xhr.responseText);
                var res = JSON.parse(xhr.responseText);
                if (res.code == 200) {
                    // alert(res.msg);
                    // alert("已提交评论");
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningSuccess");
                    el.innerText = "提交评论成功！";
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 3000);
                } else {
                    // alert("失败了吖！");
                    var el = document.createElement("div");
                    el.setAttribute("class", "warningAll");
                    el.innerText = res.message;
                    document.body.appendChild(el);
                    el.classList.add("bounce-enter-active");
                    // warningAll.style.display = 'block';
                    setTimeout(() => {
                        console.log("setTime");
                        el.classList.remove("bounce-enter-active");
                        el.classList.add("bounce-leave-active");
                        // warningAll.style.display = 'none';
                    }, 3000);
                }
            }
        }
    }
})