let sidebar = document.querySelector(".sidebar");
let closeBtn = document.querySelector("#btn");
let searchBtn = document.querySelector(".bx-search");
let mainBoxright = document.getElementById('mainBox-right');
let mainBoxleft = document.getElementById('mianBox-left');
let mainBox = document.getElementById('mainBox');
let direct = document.getElementById('direct');
// mainBoxright.style.width = (100 + '%') - sidebar.style.width;
// 获取dom元素

let countdownSp1 = document.getElementById("countdown-sp1");
let countdownSp2 = document.getElementById("countdown-sp2");
let joinJinYueFont = document.querySelector(".join-jingyue-bottom")

// 
let timeline = document.querySelector(".ui-timeLine");
closeBtn.addEventListener("click", () => {
    sidebar.classList.toggle("open");
    menuBtnChange(); //calling the function(optional)
});

function menuBtnChange() {
    if (sidebar.classList.contains("open")) {
        closeBtn.classList.replace("bx-menu", "bx-menu-alt-right");
        // 报名计时器的样式切换
        countdownSp1.classList.replace("countdown-sp1", "countdown--sp1");
        countdownSp2.classList.replace("countdown-sp2", "countdown--sp2");
        joinJinYueFont.classList.add("join-jingyue-bottom-font");
    } else {
        closeBtn.classList.replace("bx-menu-alt-right", "bx-menu");
        countdownSp1.classList.replace("countdown--sp1", "countdown-sp1");
        countdownSp2.classList.replace("countdown--sp2", "countdown-sp2");
    }
}

function thing() {
    arr = [
        "linear-gradient(200deg, #44254d, #a9c1ed)",
        "linear-gradient(200deg, #000000, #809dbe)",
        "linear-gradient(200deg, #13144b, #5c62bb)",
    ];

    r = Math.floor(Math.random() * arr.length);
    var right = document.getElementById("mainShow");
    right.style.background = arr[r];
    // for (var r = 0; r <= 2; r++) {
    //     if (r == 2) {
    //         var right = document.getElementById("mainShow");
    //         right.style.background = arr[r];
    //         r = 0;
    //     }
    //     var right = document.getElementById("mainShow");
    //     right.style.background = arr[r];
    // }

}
var div1 = document.getElementById('div1')
var div2 = document.getElementById('div2')
var div3 = document.getElementById('div3')

div1.style.display = "block";
div2.style.display = "none"
div3.style.display = "none"


function showDiv1() {

    div1.style.display = "block";
    div2.style.display = "none"
    div3.style.display = "none"


}

function showDiv2() {

    div1.style.display = "none";
    div2.style.display = "block"
    div3.style.display = "none"

}

function showDiv3() {

    div1.style.display = "none";
    div2.style.display = "none"
    div3.style.display = "block"


}

window.onload = function() {
    arr = [
        "linear-gradient(200deg, #44254d, #a9c1ed)",
        "linear-gradient(200deg, #000000, #809dbe)",
        "linear-gradient(200deg, #13144b, #5c62bb)",
    ];

    r = Math.floor(Math.random() * arr.length);
    var right = document.getElementById("mainShow");
    right.style.background = arr[r];
    // 报名截止；计时器停止
    var spanH = document.getElementById('countdown-sp1');
    spanH.style.color="black";
    var span = document.getElementById('countdown-sp2');
    span.innerText = "01" + ' 天 ' + "01" + ' 小时 \n' + "01" + ' 分钟 ' + "05" + ' 秒 ';
    span.style.color="#a8a8a8";
    setInterval(function() {
        var date = new Date();
        var currentTime = date.getTime();
        var nextDate = new Date('2022/06/5 20:0:0');
        nextTime = nextDate.getTime();

        var allTime = nextTime - currentTime;

        // 7. 把毫秒转成秒
        var allSecond = parseInt(allTime / 1000);

        // 8.转化
        var d = size(parseInt(allSecond / 3600 / 24));
        var h = size(parseInt(allSecond / 3600 % 24));
        var m = size(parseInt(allSecond / 60 % 60));
        var s = size(parseInt(allSecond % 60));

        var span = document.getElementById('countdown-sp2');
        span.innerText = d + ' 天 ' + h + ' 小时 \n' + m + ' 分钟 ' + s + ' 秒 ';
    }, 1000)
}


function size(num) {
    return num >= 10 ? num : '0' + num;
}


var w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
var h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;

// Lunbotu
window.addEventListener('load', function() {
    //获取元素
    var leftb = document.querySelector('.left');
    var rightb = document.querySelector('.right');
    var box = document.querySelector('.banner-box');
    var imgs = box.querySelector('.banner-imgs');
    var imgt = imgs.querySelectorAll('li');
    //自动翻页函数
    var timeone = setInterval(function() {
        rightf();
    }, 2000);
    //左右按钮的出现
    box.addEventListener('mouseover', function() {
        leftb.style.display = 'block';
        rightb.style.display = 'block';
        //移入时清除定时器
        clearInterval(timeone);
        timeone = null;
    })

    //左右按钮的消失
    box.addEventListener('mouseout', function() {
            leftb.style.display = 'none';
            rightb.style.display = 'none';
            //恢复定时器
            clearInterval(timeone);
            timeone = setInterval(function() {
                rightf();
            }, 2000)
        })
        //动态生成小圆圈，小圈圈模块
    var list = box.querySelector('.banner-list');
    for (var i = 0; i < imgs.children.length; i++) {
        //创建li，加入ul中
        var li = document.createElement('li');
        list.appendChild(li);
        //给小圈圈添加类名
        li.setAttribute('index', i);
        //排他思想，实现点击小圆圈，变色
        li.addEventListener('click', colors);
        //经过小圆圈，切换图片
        li.addEventListener('mouseenter', jump);
    }
    //一开始第二个亮
    list.children[1].className = 'change';
    //变色函数 
    function colors() {
        //把所有的小圆圈变白
        for (var i = 0; i < list.children.length; i++) {
            list.children[i].className = '';
        }
        //给图片对应的小圆圈上色
        var index = this.getAttribute('index');
        list.children[index].className = 'change';
    }
    //跳转函数
    function jump() {
        var index = this.getAttribute('index');
        var now = num.indexOf('two');
        //计算经过点与当前点的距离
        var dif = Math.max(index, now) - Math.min(index, now);
        // console.log(dis);
        if (index > now) {
            while (dif--) {
                rightf();
            }
        } else {
            while (dif--) {
                leftf();
            }
        }
    }
    //小圆圈跟随着图片移动
    var j = 1;

    function colort() {
        for (var i = 0; i < list.children.length; i++) {
            list.children[i].className = '';
        }
        if (j >= 5) {
            j = 0;
        } else if (j < 0) {
            j = 4;
        }
        list.children[j].className = 'change';
    }
    //翻页模块
    var num = ['one', 'two', 'three', 'four', 'five'];
    //右翻页
    rightb.addEventListener('click', rightf);

    function rightf() {
        //把数组的最后一个添加到第一个
        num.unshift(num[4]);
        //删除最后一个
        num.pop();
        //重新给li添加类名
        for (var i = 0; i < num.length; i++) {
            imgt[i].setAttribute('class', num[i]);
        }
        //通过这个全局变量来让小圆圈的颜色一起变化
        j++;
        colort();
    }
    //左翻页
    leftb.addEventListener('click', leftf)

    function leftf() {
        num.push(num[0]);
        num.shift();
        for (var i = 0; i < num.length; i++) {
            imgt[i].setAttribute('class', num[i]);
        }
        j--;
        colort();
    }

})
var xhr = new XMLHttpRequest();
xhr.open("post", "/joinplat/boss/getAnnouncement", true);
xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
xhr.withCredentials = true;
xhr.send();
xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
        var res = JSON.parse(xhr.responseText);

        if (res.code == 200) {
            console.log(res.data.announcements[0]);
            var data = res.data.announcements;
            var showout = "";
            for (i = 0; i < res.data.announcements.length; i++) {
                showout += `
                <li class="annTitle" title="${res.data.announcements[i].annTitle}">${(i+1)+':' +res.data.announcements[i].annTitle}</li>
                `
            }

            var gong1 = document.getElementById('gong1');
            gong1.innerHTML = showout;
            var liList = document.getElementById('gong1').getElementsByTagName('li');
            console.log(liList.length);
            var showmore = "";
            showmore += `
                        <p>${data[0].announcement}</p>
                    `;
            var shou = document.getElementById('shou');
            shou.innerHTML = showmore;
            for (var i = 0; i < liList.length; i++) {
                (function(j) {
                    liList[j].onclick = function() {
                        console.log(data[0].announcement);
                        var showmore = "";
                        showmore += `
                                    <p>${data[j].announcement}</p>
                                `;
                        var shou = document.getElementById('shou');
                        shou.innerHTML = showmore;

                    }
                })(i)
            }
        }
    }
}